@extends('layouts.app')

@section('title', 'Laporan Kunjungan')

@section('content')
    {{-- ========================================== --}}
    {{-- HEADER HALAMAN --}}
    {{-- ========================================== --}}
    @if (in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional']))
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 fw-bold text-gray-800">Laporan & Monitoring Visit</h1>
        </div>

        {{-- ========================================== --}}
        {{-- BAGIAN 1: MONITORING & TARGET (2 KOLOM) --}}
        {{-- ========================================== --}}


        <div class="row mb-5">

            {{-- KOLOM KIRI: TABEL MONITORING VISIT --}}
            <div class="col-lg-8 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white py-3">
                        <h6 class="mb-0 fw-bold">
                            <i class="fas fa-shoe-prints me-2 text-primary"></i>Monitoring Kunjungan (Visit)
                        </h6>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="ps-4">Sales</th>
                                        <th class="text-center">Target</th>
                                        <th class="text-center">Realisasi</th>
                                        <th>Achievement</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($monthlyRecap as $data)
                                        <tr>
                                            <td class="ps-4">
                                                <div class="fw-bold">{{ $data['name'] }}</div>
                                                <small class="text-muted" style="font-size: 0.75rem">
                                                    Target Harian: {{ $data['daily_target'] }}
                                                </small>
                                            </td>
                                            <td class="text-center">{{ $data['monthly_visit_target'] }}</td>
                                            <td class="text-center fw-bold text-primary">{{ $data['actual_visit'] }}</td>
                                            <td class="pe-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="progress flex-grow-1" style="height: 6px;">
                                                        <div class="progress-bar bg-primary"
                                                            style="width: {{ $data['visit_percentage'] }}%"></div>
                                                    </div>
                                                    <span class="ms-2 small fw-bold">{{ $data['visit_percentage'] }}%</span>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            {{-- KOLOM KANAN: KARTU TARGET OMSET --}}
            <div class="col-lg-4">
                <h6 class="fw-bold mb-3 text-secondary"><i class="fas fa-wallet me-2"></i>Target & Omset Sales</h6>

                @foreach ($monthlyRecap as $data)
                    <div class="card bg-success text-white shadow-sm border-0 mb-3 position-relative overflow-hidden">

                        {{-- Hiasan Background --}}
                        <div class="position-absolute top-0 end-0 opacity-25" style="transform: translate(20%, -20%)">
                            <i class="fas fa-trophy fa-5x"></i>
                        </div>

                        <div class="card-body position-relative">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h6 class="fw-bold mb-0 text-white" style="font-size: 1rem;">{{ $data['name'] }}</h6>
                                    <small class="text-white-50" style="font-size: 0.75rem;">Bulan Ini</small>
                                </div>

                                {{-- TOMBOL EDIT TARGET (KHUSUS MANAGER) --}}
                                @if (in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional']))
                                    <button
                                        class="btn btn-sm btn-light text-success fw-bold shadow-sm position-absolute top-0 end-0 m-3"
                                        style="z-index: 10;"
                                        onclick="openTargetModal('{{ $data['id'] }}', '{{ $data['name'] }}', '{{ $data['daily_target'] }}', '{{ $data['target_omset'] }}')">
                                        <i class="fas fa-edit me-1"></i> Atur Target
                                    </button>
                                @endif
                            </div>

                            <h4 class="fw-bold mb-0">Rp {{ number_format($data['current_omset'], 0, ',', '.') }}</h4>
                            <div class="d-flex justify-content-between align-items-end mt-1">
                                <small class="text-white-50">Target: Rp
                                    {{ number_format($data['target_omset'], 0, ',', '.') }}</small>
                                <small class="fw-bold text-white">{{ $data['omset_percentage'] }}%</small>
                            </div>

                            {{-- Progress Bar Putih --}}
                            <div class="progress mt-2" style="height: 4px; background-color: rgba(255,255,255,0.3);">
                                <div class="progress-bar bg-white" style="width: {{ $data['omset_percentage'] }}%"></div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    {{-- ========================================== --}}
    {{-- BAGIAN 2: LAPORAN DETAIL VISIT --}}
    {{-- ========================================== --}}

    {{-- Header & Filter --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 fw-bold text-gray-800">Laporan Kunjungan Lapangan</h1>

        {{-- @if (Auth::user()->role === 'sales')
            <a href="{{ route('visits.create') }}" class="btn btn-primary">
                <i class="bi bi-geo-alt-fill"></i> Check-in Baru
            </a>
        @endif --}}
    </div>

    {{-- Filter Dropdown (Hanya untuk Manager/Admin) --}}
    @if (Auth::user()->role !== 'sales')
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body py-3">
                <form action="{{ route('visits.index') }}" method="GET" class="row g-2 align-items-center">
                    <div class="col-auto">
                        <span class="fw-bold text-muted"><i class="bi bi-funnel"></i> Filter Sales:</span>
                    </div>
                    <div class="col-auto">
                        <select name="sales_id" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="">-- Tampilkan Semua --</option>
                            @foreach ($salesList as $sales)
                                <option value="{{ $sales->id }}"
                                    {{ request('sales_id') == $sales->id ? 'selected' : '' }}>
                                    {{ $sales->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-auto">
                        @if (request('sales_id'))
                            <a href="{{ route('visits.index') }}" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Reset
                            </a>
                        @endif
                    </div>
                </form>
            </div>
        </div>
    @endif

    {{-- Tabel Laporan Detail --}}
    <div class="card shadow border-0 mb-5">
        <div class="card-body">
            <div class="table-responsive">
                {{-- TAMBAHKAN class 'align-middle' DI SINI --}}
                <table class="table table-hover align-middle border-top">
                    <thead class="table-light">
                        <tr>
                            {{-- Tambahkan 'text-nowrap' agar judul kolom tidak turun baris --}}
                            <th class="py-3 text-nowrap">Tanggal</th>
                            <th class="py-3 text-nowrap">Sales</th>
                            <th class="py-3">Toko / Customer</th>
                            <th class="py-3 text-center text-nowrap">Bukti Foto</th>
                            <th class="py-3 text-center text-nowrap">Check In</th>
                            <th class="py-3 text-center text-nowrap">Check Out</th>
                            <th class="py-3 text-center text-nowrap">Durasi</th>
                            <th class="py-3 text-center text-nowrap">Lokasi</th>
                            <th class="py-3">Laporan</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($visits as $visit)
                            <tr>
                                {{-- 1. Tanggal (Bikin 2 baris biar rapi) --}}
                                <td class="text-nowrap">
                                    <div class="fw-bold text-dark">{{ $visit->created_at->format('d M Y') }}</div>
                                    <small class="text-muted">{{ $visit->created_at->format('H:i') }} WIB</small>
                                </td>

                                {{-- 2. Sales --}}
                                <td class="fw-bold text-secondary">
                                    {{ $visit->user->name }}
                                </td>

                                {{-- 3. Toko (Alamat dibatasi lebarnya biar tidak melebar banget) --}}
                                <td style="min-width: 200px;">
                                    <div class="fw-bold text-dark">{{ $visit->customer->name }}</div>
                                    <small class="text-muted d-block text-truncate" style="max-width: 250px;">
                                        {{ $visit->customer->address }}
                                    </small>
                                </td>

                                {{-- 4. Bukti Foto --}}
                                <td class="text-center">
                                    @if ($visit->photo_path)
                                        <a href="{{ asset('storage/' . $visit->photo_path) }}" target="_blank">
                                            <img src="{{ asset('storage/' . $visit->photo_path) }}"
                                                class="rounded border shadow-sm"
                                                style="width: 60px; height: 60px; object-fit: cover;">
                                        </a>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>

                                {{-- 5. Check In --}}
                                <td class="text-center fw-bold text-primary">
                                    {{ $visit->check_in_time->format('H:i') }}
                                </td>

                                {{-- 6. Check Out (Kode Logic yang tadi) --}}
                                <td class="text-center">
                                    @if ($visit->check_out_time)
                                        {{-- SUDAH SELESAI --}}
                                        <div class="d-flex flex-column align-items-center">
                                            <span class="fw-bold">
                                                {{ \Carbon\Carbon::parse($visit->check_out_time)->format('H:i') }}
                                            </span>

                                            {{-- Penanda kalau kena Auto Cutoff --}}
                                            @if (str_contains($visit->notes, '[SYSTEM]: Auto Cutoff'))
                                                <span class="badge bg-secondary mt-1" style="font-size: 0.65rem;"
                                                    data-bs-toggle="tooltip"
                                                    title="Kunjungan dihentikan otomatis oleh sistem karena > 2 jam">
                                                    <i class="bi bi-robot"></i> Auto Close
                                                </span>
                                            @endif
                                        </div>
                                    @else
                                        {{-- BELUM SELESAI --}}
                                        @if ($visit->created_at->isToday())
                                            {{-- Tombol Check Out Normal (Hanya muncul jika belum 2 jam) --}}
                                            @if (Auth::id() == $visit->user_id)
                                                <a href="{{ route('visits.perform', $visit->id) }}"
                                                    class="btn btn-warning btn-sm fw-bold">
                                                    Check Out
                                                </a>
                                            @else
                                                <span class="badge bg-warning text-dark">Sedang Visit</span>
                                            @endif
                                        @else
                                            {{-- Kasus langka: Jika kemarin lupa checkout,
                                                tapi belum buka dashboard lagi hari ini,
                                                maka tampilannya akan menunggu refresh dashboard --}}
                                            <span class="badge bg-danger">Proses Cutoff...</span>
                                        @endif
                                    @endif
                                </td>

                                {{-- 7. Durasi --}}
                                <td class="text-center">
                                    @if ($visit->check_out_time)
                                        <span class="badge bg-success">
                                            {{ round($visit->check_in_time->diffInMinutes($visit->check_out_time)) }} Menit
                                        </span>
                                    @else
                                        <span class="badge bg-warning text-dark">
                                            Berjalan {{ round($visit->check_in_time->diffInMinutes(now())) }} Menit
                                        </span>
                                    @endif
                                </td>

                                {{-- 8. Lokasi --}}
                                <td class="text-center">
                                    @if ($visit->latitude && $visit->longitude)
                                        {{-- Perbaikan Link Google Maps --}}
                                        <a href="https://www.google.com/maps?q={{ $visit->latitude }},{{ $visit->longitude }}"
                                            target="_blank" class="btn btn-sm btn-outline-success">
                                            <i class="bi bi-map"></i> Lihat Peta
                                        </a>
                                    @else
                                        <span class="badge bg-secondary">No GPS</span>
                                    @endif
                                </td>

                                {{-- 9. Laporan (Kasih style italic) --}}
                                <td style="min-width: 200px;">
                                    {{-- Tampilkan potongan teks maksimal 50 karakter --}}
                                    <span class="text-muted fst-italic d-block mb-1">
                                        "{{ Str::limit($visit->notes, 50) }}"
                                    </span>

                                    {{-- Logic: Jika teks lebih panjang dari 50 karakter, munculkan tombol --}}
                                    @if (strlen($visit->notes) > 50)
                                        <button type="button"
                                            class="btn btn-link p-0 text-primary fw-bold text-decoration-none"
                                            style="font-size: 0.75rem;"
                                            onclick="showNoteModal(`{{ str_replace(["\r", "\n"], ' ', addslashes($visit->notes)) }}`)">
                                            Baca Selengkapnya
                                        </button>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="text-center py-5 text-muted">
                                    <img src="https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg"
                                        width="100" class="mb-3 opacity-50">
                                    <p>Belum ada data kunjungan.</p>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                {{ $visits->links() }}
            </div>
        </div>
    </div>

    {{-- ========================================== --}}
    {{-- MODAL & SCRIPT --}}
    {{-- ========================================== --}}

    {{-- MODAL EDIT TARGET --}}
    <div class="modal fade" id="targetModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Atur Target Sales</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="{{ route('visits.updateTarget') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="modalUserId">

                        {{-- Info Sales --}}
                        <div class="mb-3">
                            <label class="form-label">Nama Sales</label>
                            <input type="text" class="form-control bg-light" id="modalUserName" readonly>
                        </div>

                        {{-- Target Visit --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold">Target Visit Harian</label>
                            <div class="input-group">
                                <input type="number" name="daily_visit_target" id="modalUserTargetVisit"
                                    class="form-control" min="1" required>
                                <span class="input-group-text">Kunjungan / Hari</span>
                            </div>
                        </div>

                        {{-- Target Omset --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold text-success">Target Omset Bulanan</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" name="sales_target" id="modalUserTargetOmset" class="form-control"
                                    min="0" required>
                            </div>
                            <small class="text-muted">Masukkan angka tanpa titik (Contoh: 50000000)</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Target</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- MODAL BACA CATATAN LENGKAP --}}
<div class="modal fade" id="noteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h6 class="modal-title fw-bold"><i class="bi bi-journal-text me-2"></i>Catatan Kunjungan</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="fullNoteContent" class="mb-0 text-secondary" style="white-space: pre-wrap;"></p>
            </div>
            <div class="modal-footer py-1">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script>
    function showNoteModal(noteContent) {
        // 1. Isi teks ke dalam modal
        document.getElementById('fullNoteContent').innerText = noteContent;

        // 2. Tampilkan modal
        new bootstrap.Modal(document.getElementById('noteModal')).show();
    }
</script>

    {{-- MODAL NOTIFIKASI --}}
    {{-- SCRIPT PENDUKUNG MODAL --}}
    <script>
        function openTargetModal(id, name, targetVisit, targetOmset) {
            // Isi data ke dalam form modal
            document.getElementById('modalUserId').value = id;
            document.getElementById('modalUserName').value = name;
            document.getElementById('modalUserTargetVisit').value = targetVisit;
            document.getElementById('modalUserTargetOmset').value = targetOmset;

            // Buka Modal
            var myModal = new bootstrap.Modal(document.getElementById('targetModal'));
            myModal.show();
        }
    </script>
@endsection
