@extends('layouts.app')

@section('title', 'Data Produk')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
        <h1 class="h3 mb-0 text-gray-800">Data Produk & Stok</h1>

        {{-- BAGIAN TOTAL ASET --}}
        <div class="mt-1 small text-muted">
            <span class="me-3">
                <i class="bi bi-cash-stack me-1"></i> Total Aset:
                <span class="fw-bold text-success">
                    Rp {{ number_format($totalAsset ?? 0, 0, ',', '.') }}
                </span>
            </span>
            <span>
                <i class="bi bi-box-seam me-1"></i> Total Stok:
                <span class="fw-bold text-primary">
                    {{ number_format($totalStock ?? 0, 0, ',', '.') }} Unit
                </span>
            </span>
        </div>

    </div>
        {{-- TOMBOL TAMBAH PRODUK (Hanya Manager/Kepala Gudang/Admin Gudang) --}}

        @if (in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang']))
            <a href="{{ route('products.create') }}" class="btn btn-primary shadow-sm">
                <i class="bi bi-plus-lg me-2"></i> Tambah Produk
            </a>
        @endif
    </div>

    {{-- 1. TABEL KHUSUS BARANG MENIPIS (Hanya Purchase/Manager/Kepala Gudang) --}}
    @if (in_array(Auth::user()->role, ['purchase', 'manager_operasional', 'kepala_gudang']))
        @if (isset($lowStockProducts) && $lowStockProducts->count() > 0)
            <div class="card border-warning mb-4 shadow-sm">
                <div
                    class="card-header bg-warning bg-opacity-10 fw-bold text-warning-emphasis d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-exclamation-triangle-fill me-2"></i> Perlu Restock (Stok Menipis)</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0 align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3">Produk</th>
                                    <th class="text-center">Sisa Stok</th>
                                    <th>Status Pemesanan</th>
                                    <th class="text-end pe-3">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($lowStockProducts as $item)
                                    <tr>
                                        <td class="ps-3 fw-bold">{{ $item->name }}</td>
                                        <td class="text-center">
                                            <span class="badge bg-danger">{{ $item->stock }} Unit</span>
                                        </td>
                                        <td>
                                            @if ($item->restock_date)
                                                <span class="badge bg-info text-dark border border-info">
                                                    <i class="bi bi-calendar-check me-1"></i>
                                                    Dipesan: {{ date('d/m/Y', strtotime($item->restock_date)) }}
                                                </span>
                                            @else
                                                <span class="badge bg-secondary opacity-50">Belum Pesan</span>
                                            @endif
                                        </td>
                                        <td class="text-end pe-3">
                                            {{-- TOMBOL BUKA MODAL --}}
                                            <button class="btn btn-sm btn-outline-primary"
                                                onclick="openRestockModal('{{ $item->id }}', '{{ $item->name }}', '{{ $item->restock_date }}')">
                                                <i class="bi bi-pencil-square"></i> Update Info
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif
    @endif

    {{-- FILTER PENCARIAN --}}
    {{-- (Kode Filter Anda yang lama tetap sama, tidak saya ubah) --}}
    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-body">
            <form action="{{ route('products.index') }}" method="GET" class="row g-2">
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama produk..."
                        value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="category" class="form-select" onchange="this.form.submit()">
                        <option value="">- Semua Kategori -</option>
                        @foreach ($categories as $cat)
                            <option value="{{ $cat }}" {{ request('category') == $cat ? 'selected' : '' }}>
                                {{ $cat }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="is_discount" class="form-select" onchange="this.form.submit()">
                        <option value="">- Semua Harga -</option>
                        <option value="1" {{ request('is_discount') == '1' ? 'selected' : '' }}>🏷️ Diskon</option>
                    </select>
                </div>
                {{-- Ganti bagian kolom tombol CARI dengan ini --}}
                <div class="col-md-2 d-flex gap-1">
                    {{-- 1. Tombol Cari (Tetap) --}}
                    <button type="submit" class="btn btn-primary flex-fill">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>

                    {{-- 2. Tombol Reset (BARU) --}}
                    {{-- Hanya muncul jika sedang mencari sesuatu --}}
                    @if (request('search') || request('category') || request('price_order'))
                        <a href="{{ route('products.index') }}" class="btn btn-danger" title="Reset Filter">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    @else
                        {{-- Tombol Refresh biasa jika tidak ada filter --}}
                        <a href="{{ route('products.index') }}" class="btn btn-light border" title="Refresh Data">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    {{-- 2. TABEL UTAMA --}}
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3" width="80">Gambar</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>

                            {{-- LOGIKA HEADER TABEL --}}
                            @if (Auth::user()->role === 'purchase')
                                {{-- Tampilan Khusus Purchase (2 Kolom Harga) --}}
                                <th>Harga Normal</th>
                                <th style="width: 200px;" class="text-danger bg-danger bg-opacity-10">Set Harga Diskon</th>
                            @else
                                {{-- Tampilan User Lain (1 Kolom Gabungan) --}}
                                <th>Harga Satuan</th>
                            @endif

                            <th class="text-center">Stok</th>

                            {{-- Aksi (Disembunyikan utk Purchase agar fokus di harga, atau dimunculkan jika perlu) --}}
                            @if (in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang']))
                                <th class="text-center pe-4" width="100">Aksi</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($products as $product)
                            <tr>
                                <td class="text-center" style="width: 80px;">
                                    @if ($product->image)
                                        {{-- 1. THUMBNAIL (BISA DIKLIK) --}}
                                        <a href="#" data-bs-toggle="modal"
                                            data-bs-target="#imgModal{{ $product->id }}">
                                            <img src="{{ asset('storage/products/' . $product->image) }}"
                                                class="rounded border shadow-sm" width="50" height="50"
                                                style="object-fit: cover; cursor: pointer;" alt="Produk">
                                        </a>

                                        {{-- 2. MODAL ZOOM (POPUP) --}}
                                        <div class="modal fade" id="imgModal{{ $product->id }}" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h6 class="modal-title fw-bold">{{ $product->name }}</h6>
                                                        <button type="button" class="btn-close"
                                                            data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body text-center p-0 bg-light">
                                                        <img src="{{ asset('storage/products/' . $product->image) }}"
                                                            class="img-fluid" style="max-height: 500px;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @else
                                        {{-- 3. JIKA TIDAK ADA GAMBAR (PLACEHOLDER SIMPEL) --}}
                                        <img src="https://via.placeholder.com/50?text=No+Img"
                                            class="rounded border opacity-50" width="50" height="50">
                                    @endif
                                </td>
                                <td>
                                    <div class="fw-bold text-dark">{{ $product->name }}</div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border">{{ $product->category }}</span>
                                </td>

                                {{-- LOGIKA ISI TABEL (BODY) --}}
                                @if (Auth::user()->role === 'purchase')
                                    {{-- A. TAMPILAN PURCHASE (BISA EDIT) --}}
                                    <td>
                                        <span class="fw-bold text-dark">Rp
                                            {{ number_format($product->price, 0, ',', '.') }}</span>
                                    </td>
                                    <td class="bg-danger bg-opacity-10">
                                        {{-- Form Input Cepat Diskon --}}
                                        <form action="{{ route('products.updateDiscount', $product->id) }}"
                                            method="POST" class="d-flex gap-1">
                                            @csrf
                                            <input type="number" name="discount_price"
                                                class="form-control form-control-sm border-danger text-danger fw-bold"
                                                value="{{ $product->discount_price == 0 ? '' : $product->discount_price }}"
                                                placeholder="No Disc">
                                            <button type="submit" class="btn btn-sm btn-danger shadow-sm"
                                                title="Simpan Diskon">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </form>
                                    </td>
                                @else
                                    {{-- B. TAMPILAN USER LAIN (CANTIK SAJA) --}}
                                    <td>
                                        @if ($product->discount_price && $product->discount_price > 0)
                                            <div class="text-decoration-line-through text-muted small">
                                                Rp {{ number_format($product->price, 0, ',', '.') }}
                                            </div>
                                            <div class="fw-bold text-danger">
                                                Rp {{ number_format($product->discount_price, 0, ',', '.') }}
                                            </div>
                                        @else
                                            <div class="fw-bold text-primary">
                                                Rp {{ number_format($product->price, 0, ',', '.') }}
                                            </div>
                                        @endif
                                    </td>
                                @endif

                                <td class="text-center">
                                    @if ($product->stock <= 10)
                                        <span class="badge bg-warning text-dark">{{ $product->stock }}</span>
                                    @else
                                        <span class="badge bg-success">{{ $product->stock }}</span>
                                    @endif
                                </td>

                                @if (in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang']))
                                    <td class="text-center" style="white-space: nowrap;">
                                        {{-- 🔥 WAJIB ADA DIV PEMBUNGKUS 'd-flex' INI AGAR SEJAJAR 🔥 --}}
                                        <div class="d-flex justify-content-center align-items-center gap-1">

                                            {{-- 1. TOMBOL EDIT --}}
                                            <a href="{{ route('products.edit', $product->id) }}"
                                                class="btn btn-sm btn-outline-primary" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>

                                            {{-- 2. FORM HAPUS (Pastikan ada class 'm-0' biar ga ada margin aneh) --}}
                                            <form action="{{ route('products.destroy', $product->id) }}" method="POST"
                                                class="d-inline m-0">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger shadow-sm"
                                                    onclick="confirmSubmit(event, 'Hapus Produk?', 'Data yang dihapus tidak bisa dikembalikan!')"
                                                    title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>

                                        </div>
                                    </td>
                                @endif
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-4">Tidak ada data.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="p-3">{{ $products->links() }}</div>
        </div>
    </div>

    {{-- 3. MODAL RESTOCK (BARU) --}}
    <div class="modal fade" id="restockModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-warning bg-opacity-25">
                    <h5 class="modal-title fw-bold">Update Info Restock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="restockForm" action="" method="POST">
                    @csrf
                    <div class="modal-body">
                        <p>Barang: <strong id="modalProductName"></strong></p>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Pemesanan Barang (PO ke Pabrik)</label>
                            <input type="date" name="restock_date" id="modalRestockDate" class="form-control"
                                required>
                            <small class="text-muted">Isi tanggal kapan barang dipesan.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Info</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openRestockModal(id, name, date) {
            document.getElementById('modalProductName').innerText = name;
            document.getElementById('modalRestockDate').value = date;

            // Set Action Form Dinamis
            let url = "{{ route('products.updateRestock', ':id') }}";
            url = url.replace(':id', id);
            document.getElementById('restockForm').action = url;

            new bootstrap.Modal(document.getElementById('restockModal')).show();
        }
    </script>

@endsection
