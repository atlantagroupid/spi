@extends('layouts.app')

@section('title', 'Riwayat Transaksi')

@section('content')

    {{-- HEADER & TOMBOL AKSI --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-clock-history me-2"></i>Riwayat Order</h5>
        <div>
            {{-- Tombol Buka/Tutup Filter --}}
            <button class="btn btn-outline-secondary btn-sm me-1" type="button" data-bs-toggle="collapse"
                data-bs-target="#filterCollapse">
                <i class="bi bi-funnel"></i> Filter
            </button>
            {{-- Tombol Tambah Order --}}
            @if (in_array(Auth::user()->role, ['sales', 'manager_operasional']))
                <a href="{{ route('orders.create') }}" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-lg"></i> Baru
                </a>
            @endif
        </div>
    </div>

    {{-- CARD FILTER (DEFAULT TERTUTUP AGAR RAPI) --}}
    <div class="collapse mb-4 {{ request('search') || request('start_date') ? 'show' : '' }}" id="filterCollapse">
        <div class="card border-0 shadow-sm bg-light">
            <div class="card-body p-3">
                <form action="{{ route('orders.index') }}" method="GET">
                    <div class="row g-2">
                        {{-- 1. Cari Invoice/Toko --}}
                        <div class="col-12 col-md-4">
                            <label class="small text-muted fw-bold mb-1">Cari Data</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0"><i class="bi bi-search"></i></span>
                                <input type="text" name="search" class="form-control border-start-0"
                                    placeholder="Invoice / Nama Toko..." value="{{ request('search') }}">
                            </div>
                        </div>

                        {{-- 2. Rentang Tanggal (Satu baris di HP biar hemat) --}}
                        <div class="col-6 col-md-3">
                            <label class="small text-muted fw-bold mb-1">Dari Tanggal</label>
                            <input type="date" name="start_date" class="form-control"
                                value="{{ request('start_date') }}">
                        </div>
                        <div class="col-6 col-md-3">
                            <label class="small text-muted fw-bold mb-1">Sampai</label>
                            <input type="date" name="end_date" class="form-control" value="{{ request('end_date') }}">
                        </div>

                        {{-- 3. Status --}}
                        <div class="col-12 col-md-2">
                            <label class="small text-muted fw-bold mb-1">Status</label>
                            <select name="status" class="form-select">
                                <option value="">- Semua -</option>
                                <option value="pending_approval"
                                    {{ request('status') == 'pending_approval' ? 'selected' : '' }}>Menunggu</option>
                                <option value="approved" {{ request('status') == 'approved' ? 'selected' : '' }}>Disetujui
                                </option>
                                <option value="rejected" {{ request('status') == 'rejected' ? 'selected' : '' }}>Ditolak
                                </option>
                                <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Selesai
                                </option>
                            </select>
                        </div>

                        {{-- 4. Tombol Submit --}}
                        <div class="col-12 d-flex justify-content-end mt-3 gap-2">
                            <a href="{{ route('orders.index') }}" class="btn btn-light btn-sm text-muted">Reset</a>
                            <button type="submit" class="btn btn-primary btn-sm px-4">Terapkan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- 3. TABEL TRANSAKSI --}}
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="ps-4 py-3">No Invoice & Tanggal</th>
                            <th>Pelanggan & Sales</th>
                            <th>Total Transaksi</th>
                            <th class="text-center">Status Order</th>
                            <th class="text-center pe-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($orders as $order)
                            <tr>
                                {{-- 1. Invoice --}}
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary bg-opacity-10 text-primary rounded p-2 me-3">
                                            <i class="bi bi-receipt fs-5"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark">{{ $order->invoice_number }}</div>
                                            <div class="small text-muted">
                                                <i class="bi bi-calendar3 me-1"></i>
                                                {{ $order->created_at->format('d M Y, H:i') }}
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                {{-- 2. Pelanggan --}}
                                <td>
                                    <div class="fw-bold text-dark">{{ $order->customer->name }}</div>
                                    <div class="small text-muted">
                                        <i class="bi bi-person-badge me-1"></i> {{ $order->user->name ?? '-' }}
                                    </div>
                                </td>

                                {{-- 3. Total --}}
                                <td>
                                    <div class="fw-bold text-primary fs-6">
                                        Rp {{ number_format($order->total_price, 0, ',', '.') }}
                                    </div>
                                    @if ($order->payment_status == 'paid')
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success px-2"
                                            style="font-size: 0.7rem;">LUNAS</span>
                                    @else
                                        <span
                                            class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary px-2"
                                            style="font-size: 0.7rem;">BELUM LUNAS</span>
                                    @endif
                                </td>

                                {{-- 4. Status (Badge Keren) --}}
                                <td class="text-center">
                                    @if ($order->status == 'pending_approval')
                                        <span class="badge bg-warning text-dark border border-warning shadow-sm">
                                            <i class="bi bi-hourglass-split me-1"></i> Menunggu Approval
                                        </span>
                                    @elseif($order->status == 'approved')
                                        <span class="badge bg-info text-dark border border-info shadow-sm">
                                            <i class="bi bi-check-circle me-1"></i> Disetujui Manager
                                        </span>
                                    @elseif($order->status == 'processed')
                                        <span class="badge bg-primary border border-primary shadow-sm">
                                            <i class="bi bi-truck me-1"></i> Sedang Diantar
                                        </span>
                                    @elseif($order->status == 'completed')
                                        <span class="badge bg-success border border-success shadow-sm">
                                            <i class="bi bi-check-all me-1"></i> Selesai
                                        </span>
                                    @elseif($order->status == 'rejected')
                                        <span class="badge bg-danger border border-danger shadow-sm">
                                            <i class="bi bi-x-circle me-1"></i> Ditolak
                                        </span>
                                    @elseif($order->status == 'cancelled')
                                        <span class="badge bg-dark border border-dark shadow-sm">
                                            <i class="bi bi-slash-circle me-1"></i> Batal
                                        </span>
                                    @endif
                                </td>

                                {{-- 5. Tombol Aksi --}}
                                <td class="text-center pe-4">
                                    <div class="btn-group shadow-sm">
                                        {{-- Detail --}}
                                        <a href="{{ route('orders.show', $order->id) }}"
                                            class="btn btn-sm btn-light border" title="Lihat Detail">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        {{-- LOGIC TOMBOL EDIT: Hanya muncul jika DITOLAK atau MENUNGGU --}}
                                        @if (in_array($order->status, ['pending_approval', 'rejected']) && Auth::user()->id == $order->user_id)
                                            <a href="{{ route('orders.edit', $order->id) }}"
                                                class="btn btn-warning btn-sm text-dark" title="Edit / Revisi">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                        @endif

                                        {{-- MANAGER: Approve/Reject --}}
                                        @if (in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis']) && $order->status == 'pending_approval')
                                            <form action="{{ route('orders.approve', $order->id) }}" method="POST"
                                                onsubmit="return confirm('Setujui order ini?');" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-success text-white"
                                                    title="Approve">
                                                    <i class="bi bi-check-lg"></i>
                                                </button>
                                            </form>
                                            <form action="{{ route('orders.reject', $order->id) }}" method="POST"
                                                onsubmit="return confirm('Tolak order ini?');" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-danger text-white"
                                                    title="Reject">
                                                    <i class="bi bi-x-lg"></i>
                                                </button>
                                            </form>
                                        @endif

                                        {{-- KASIR: Proses --}}
                                        @if (Auth::user()->role == 'kasir' && $order->status == 'approved')
                                            <button type="button" class="btn btn-sm btn-primary"
                                                title="Proses Pengiriman"
                                                onclick="openProcessModal('{{ $order->id }}', '{{ $order->invoice_number }}')">
                                                <i class="bi bi-truck"></i>
                                            </button>
                                        @endif

                                        {{-- LIHAT BUKTI ANTAR (Jika Ada) --}}
                                        @if ($order->delivery_proof)
                                            <a href="{{ asset('storage/delivery_proofs/' . $order->delivery_proof) }}"
                                                target="_blank" class="btn btn-sm btn-info text-white"
                                                title="Bukti Antar">
                                                <i class="bi bi-receipt"></i>
                                            </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <div class="d-flex flex-column align-items-center justify-content-center text-muted">
                                        <i class="bi bi-inbox fs-1 opacity-25 mb-3"></i>
                                        <h6 class="fw-bold">Belum Ada Transaksi</h6>
                                        <p class="small mb-0">Data transaksi yang dibuat akan muncul di sini.</p>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{-- Pagination --}}
            <div class="p-3 border-top">
                {{ $orders->withQueryString()->links() }}
            </div>
        </div>
    </div>

    {{-- 4. MODAL PROSES KASIR (WAJIB ADA) --}}
    <div class="modal fade" id="processModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-truck me-2"></i> Proses Pengantaran</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="processForm" action="" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <p>Memproses Invoice: <strong id="modalSoNumber" class="text-primary"></strong></p>

                        <div class="alert alert-warning small border-warning text-dark">
                            <i class="bi bi-exclamation-circle-fill me-1"></i>
                            Pastikan barang sudah naik ke armada pengiriman sebelum memproses.
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Upload Surat Jalan / Bukti Muat</label>
                            <input type="file" name="delivery_proof" class="form-control" required accept="image/*">
                            <small class="text-muted">Format: JPG/PNG. Max 2MB.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-send-fill me-2"></i> Proses & Jalan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openProcessModal(id, invoice) {
            document.getElementById('modalSoNumber').innerText = invoice;
            let url = "{{ route('orders.process', ':id') }}";
            url = url.replace(':id', id);
            document.getElementById('processForm').action = url;
            new bootstrap.Modal(document.getElementById('processModal')).show();
        }
    </script>

@endsection
