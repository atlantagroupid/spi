@extends('layouts.app')

@section('title', 'Buat Sales Order Baru')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold text-gray-800">Buat Sales Order (SO)</h1>
            <p class="text-muted small mb-0">Isi form di bawah untuk membuat transaksi baru.</p>
        </div>
        <a href="{{ route('orders.index') }}" class="btn btn-secondary shadow-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    {{-- ALERT ERROR YANG LEBIH RAPI --}}
    @if ($errors->any())
        <div class="alert alert-danger border-0 shadow-sm mb-4">
            <div class="d-flex align-items-center">
                <i class="bi bi-exclamation-triangle-fill fs-4 me-3"></i>
                <div>
                    <strong class="d-block mb-1">Gagal Menyimpan Order!</strong>
                    <ul class="mb-0 ps-3 small">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    @endif

    <form action="{{ route('orders.store') }}" method="POST" enctype="multipart/form-data" id="orderForm">
        @csrf

        <div class="row g-4">

            {{-- KOLOM KIRI: INFO PELANGGAN --}}
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-primary text-white py-3">
                        <h6 class="mb-0 fw-bold"><i class="bi bi-person-lines-fill me-2"></i> 1. Informasi Pelanggan</h6>
                    </div>
                    <div class="card-body">

                        {{-- Pilih Customer --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-muted">Pilih Customer</label>
                            <select name="customer_id" id="customerSelect"
                                class="form-select @error('customer_id') is-invalid @enderror">
                                <option value="">-- Pilih Customer --</option>
                                @forelse($customers as $customer)
                                    <option value="{{ $customer->id }}" data-top="{{ $customer->top_days }}">
                                        {{ $customer->name }} ({{ $customer->category }})
                                    </option>
                                @empty
                                    {{-- Jika list kosong --}}
                                    <option value="" disabled>Anda belum memiliki data Customer.</option>
                                @endforelse
                            </select>
                        </div>

                        {{-- Jatuh Tempo --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-muted">Jatuh Tempo (Due Date)</label>
                            <input type="date" name="due_date" id="dueDateInput"
                                class="form-control bg-light @error('due_date') is-invalid @enderror"
                                value="{{ date('Y-m-d') }}" readonly>
                            <div class="form-text small text-primary" id="topInfo">
                                <i class="bi bi-info-circle"></i> Pilih customer untuk cek TOP.
                            </div>
                        </div>

                        {{-- Catatan --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-muted">Catatan (Opsional)</label>
                            <textarea name="notes" class="form-control" rows="3" placeholder="Contoh: Barang dikirim siang hari...">{{ old('notes') }}</textarea>
                        </div>

                        {{-- Upload Bukti --}}
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-muted">Upload PO / SPK</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="bi bi-paperclip"></i></span>
                                <input type="file" name="payment_proof"
                                    class="form-control @error('payment_proof') is-invalid @enderror">
                            </div>
                            <small class="text-danger d-none" id="proofWarning">* Wajib untuk Customer Kredit (TOP)</small>
                            <small class="text-muted d-block">Format: JPG, PNG, PDF. Max 2MB.</small>
                        </div>

                    </div>
                </div>
            </div>

            {{-- KOLOM KANAN: KERANJANG BELANJA --}}
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white py-3 border-bottom">
                        <h6 class="mb-0 fw-bold text-dark"><i class="bi bi-cart-check me-2"></i> 2. Pilih Produk & Stok</h6>
                    </div>
                    <div class="card-body">

                        {{-- TOOLBAR TAMBAH PRODUK --}}
                        <div class="bg-light p-3 rounded mb-3 border">
                            <div class="row g-2 align-items-end">
                                <div class="col-md-7">
                                    <label class="form-label small fw-bold text-muted">Produk</label>
                                    <select id="productSelect" class="form-select">
                                        <option value="" data-price="0">-- Pilih Produk --</option>
                                        @foreach ($products as $product)
                                            <option value="{{ $product->id }}"
                                                data-price="{{ $product->discount_price ?? $product->price }}"
                                                data-name="{{ $product->name }}" data-stock="{{ $product->stock }}">
                                                {{ $product->name }} (Stok: {{ $product->stock }})
                                                @if ($product->discount_price)
                                                    [DISKON]
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted">Qty</label>
                                    <input type="number" id="qtyInput" class="form-control" value="1" min="1">
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-primary w-100" onclick="addToCart()">
                                        <i class="bi bi-plus-lg"></i> Tambah
                                    </button>
                                </div>
                            </div>
                        </div>

                        {{-- TABEL KERANJANG --}}
                        <div class="table-responsive mb-3">
                            <table class="table table-striped table-hover align-middle border" id="cartTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>Produk</th>
                                        <th width="100" class="text-center">Qty</th>
                                        <th width="150" class="text-end">Harga</th>
                                        <th width="150" class="text-end">Total</th>
                                        <th width="50" class="text-center">#</th>
                                    </tr>
                                </thead>
                                <tbody id="cartBody">
                                    {{-- KOSONG --}}
                                    <tr id="emptyRow">
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="bi bi-basket fs-1 d-block mb-2 opacity-25"></i>
                                            Belum ada produk di keranjang.
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot class="border-top-2">
                                    <tr class="bg-light fw-bold" style="font-size: 1.1rem;">
                                        <td colspan="3" class="text-end text-muted">ESTIMASI TOTAL:</td>
                                        <td class="text-end text-primary" id="grandTotalDisplay">Rp 0</td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        {{-- TOMBOL SUBMIT --}}
                        <div class="text-end">
                            <button type="submit" class="btn btn-success btn-lg px-5 shadow fw-bold" id="btnSubmit">
                                <i class="bi bi-check-circle me-2"></i> SIMPAN ORDER
                            </button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>

    {{-- JAVASCRIPT --}}
    <script>
        // --- 1. INISIALISASI VARIABEL GLOBAL ---
        // Kita tempelkan ke window agar bisa diakses dari mana saja
        window.cartTotal = 0;

        document.addEventListener('DOMContentLoaded', function() {
            // --- 2. LOGIKA PILIH CUSTOMER (TOP) ---
            const customerSelect = document.getElementById('customerSelect');

            // Cek dulu apakah elemennya ada (untuk menghindari error null)
            if (customerSelect) {
                customerSelect.addEventListener('change', function() {
                    let option = this.options[this.selectedIndex];
                    let top = option.getAttribute('data-top');

                    if (top) {
                        // Hitung Tanggal Jatuh Tempo
                        let today = new Date();
                        today.setDate(today.getDate() + parseInt(top));
                        let dateString = today.toISOString().split('T')[0];

                        document.getElementById('dueDateInput').value = dateString;

                        // Tampilkan Info
                        let msg = top > 0 ?
                            `<span class="text-danger fw-bold"><i class="bi bi-clock-history"></i> Kredit (TOP ${top} Hari). Wajib Upload Bukti.</span>` :
                            `<span class="text-success fw-bold"><i class="bi bi-cash-coin"></i> Cash / Tunai.</span>`;

                        document.getElementById('topInfo').innerHTML = msg;

                        // Toggle Warning Upload
                        let warning = document.getElementById('proofWarning');
                        if (top > 0) warning.classList.remove('d-none');
                        else warning.classList.add('d-none');

                    } else {
                        // Reset jika tidak ada customer dipilih
                        document.getElementById('topInfo').innerText = "Pilih customer untuk cek TOP.";
                        document.getElementById('dueDateInput').value = "{{ date('Y-m-d') }}";
                        document.getElementById('proofWarning').classList.add('d-none');
                    }
                });
            }
        });

        // --- 3. FUNCTION TAMBAH BARANG (GLOBAL) ---
        // Ditaruh di luar DOMContentLoaded agar bisa dipanggil onclick=""
        function addToCart() {
            let productSelect = document.getElementById('productSelect');
            let qtyInput = document.getElementById('qtyInput');

            let id = productSelect.value;

            // Validasi Awal
            if (!id) {
                // Gunakan SweetAlert jika ada, kalau tidak pakai alert biasa
                if (typeof Swal !== 'undefined') {
                    Swal.fire('Ups!', 'Silakan pilih produk terlebih dahulu.', 'warning');
                } else {
                    alert('Silakan pilih produk terlebih dahulu!');
                }
                return;
            }

            let selectedOption = productSelect.options[productSelect.selectedIndex];
            let name = selectedOption.getAttribute('data-name');
            let price = parseFloat(selectedOption.getAttribute('data-price') || 0);
            let stock = parseInt(selectedOption.getAttribute('data-stock') || 0);
            let qty = parseInt(qtyInput.value);

            // Validasi Stok
            if (qty <= 0) {
                alert('Jumlah (Qty) minimal 1!');
                return;
            }
            if (qty > stock) {
                alert('Stok tidak cukup! Sisa: ' + stock);
                return;
            }

            // Hapus Baris "Keranjang Kosong"
            let emptyRow = document.getElementById('emptyRow');
            if (emptyRow) emptyRow.remove();

            // Hitung
            let subtotal = price * qty;
            window.cartTotal += subtotal; // Pakai window.cartTotal biar aman

            // Render Baris Baru
            let tbody = document.getElementById('cartBody');
            let row = document.createElement('tr');

            row.innerHTML = `
            <td>
                <input type="hidden" name="product_id[]" value="${id}">
                <span class="fw-bold text-dark">${name}</span>
            </td>
            <td class="text-center">
                <input type="hidden" name="quantity[]" value="${qty}">
                <span class="badge bg-light text-dark border">${qty}</span>
            </td>
            <td class="text-end text-muted small">
                Rp ${new Intl.NumberFormat('id-ID').format(price)}
            </td>
            <td class="text-end fw-bold text-dark">
                Rp ${new Intl.NumberFormat('id-ID').format(subtotal)}
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-danger border-0" onclick="removeRow(this, ${subtotal})">
                    <i class="bi bi-trash-fill"></i>
                </button>
            </td>
        `;

            tbody.appendChild(row);
            updateGrandTotal();

            // Reset Input
            productSelect.value = "";
            qtyInput.value = 1;
        }

        // --- 4. FUNCTION HAPUS BARIS ---
        function removeRow(btn, subtotal) {
            let row = btn.closest('tr');
            row.remove();

            window.cartTotal -= subtotal;
            updateGrandTotal();

            // Cek Kosong
            let tbody = document.getElementById('cartBody');
            if (tbody.children.length === 0) {
                tbody.innerHTML =
                    `<tr id="emptyRow"><td colspan="5" class="text-center py-5 text-muted"><i class="bi bi-basket fs-1 d-block mb-2 opacity-25"></i>Keranjang Kosong</td></tr>`;
            }
        }

        // --- 5. FUNCTION UPDATE TOTAL ---
        function updateGrandTotal() {
            let display = document.getElementById('grandTotalDisplay');
            if (display) {
                display.innerText = 'Rp ' + new Intl.NumberFormat('id-ID').format(window.cartTotal);
            }
        }
    </script>

@endsection
