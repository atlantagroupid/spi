@extends('layouts.app')

{{-- 1. JUDUL HALAMAN --}}
@section('title', 'Detail Order #' . $order->invoice_number)

@section('content')

    {{-- A. HEADER TOMBOL (KEMBALI & CETAK) --}}
    <div class="d-flex justify-content-between align-items-center mb-4">
        <a href="{{ route('orders.index') }}" class="btn btn-secondary shadow-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>

        <div>
            {{-- Tombol Cetak (Disembunyikan untuk Sales, sesuai request awal) --}}
            @if (Auth::user()->role !== 'sales')
                <button onclick="window.print()" class="btn btn-outline-secondary shadow-sm">
                    <i class="bi bi-printer me-1"></i> Cetak Invoice
                </button>
            @endif
        </div>
    </div>

    {{-- B. BANNER STATUS & AKSI (FITUR BARU) --}}

    {{-- 1. Jika Status SHIPPED (Sedang Dikirim) -> Munculkan Tombol Konfirmasi --}}
    @if ($order->status == 'shipped' || $order->status == 'processed')
        <div
            class="alert alert-info shadow-sm border-0 d-flex flex-column flex-md-row align-items-center justify-content-between p-4 mb-4">
            <div class="d-flex align-items-center mb-3 mb-md-0">
                <div class="bg-white p-3 rounded-circle text-info me-3 shadow-sm">
                    <i class="bi bi-truck fs-3"></i>
                </div>
                <div>
                    <h5 class="fw-bold mb-1">Paket Sedang Dikirim</h5>
                    <p class="mb-0 text-muted small">Surat jalan sudah diterbitkan Kasir. Menunggu barang sampai di lokasi.
                    </p>
                </div>
            </div>

            <form action="{{ route('orders.confirmArrival', $order->id) }}" method="POST">
                @csrf
                {{-- Perhatikan cara panggilnya: confirmSubmit(event, 'Judul', 'Pesan') --}}
                <button type="submit" class="btn btn-primary btn-lg fw-bold shadow-sm"
                    onclick="confirmSubmit(event, 'Konfirmasi Terima Barang', 'Apakah Anda yakin barang fisik sudah diterima dengan baik oleh Customer?')">
                    <i class="bi bi-check-circle-fill me-2"></i> Konfirmasi Barang Diterima
                </button>
            </form>
        </div>

        {{-- 2. Jika Status DELIVERED (Diterima) -> Info Menunggu Pelunasan --}}
    @elseif ($order->status == 'delivered')
        <div class="alert alert-success shadow-sm border-0 d-flex align-items-center p-4 mb-4">
            <div class="bg-white p-3 rounded-circle text-success me-3 shadow-sm">
                <i class="bi bi-box-seam-fill fs-3"></i>
            </div>
            <div>
                <h5 class="fw-bold mb-1">Barang Sudah Diterima</h5>
                @if ($order->payment_status == 'paid')
                    <p class="mb-0 text-muted small">Transaksi selesai. Terima kasih.</p>
                @else
                    <p class="mb-0 text-dark small">Barang sudah sampai, namun status pembayaran belum
                        <strong>LUNAS</strong>. Order akan selesai otomatis setelah pelunasan.</p>
                @endif
            </div>
        </div>
    @endif


    {{-- C. KARTU INVOICE (AREA PRINT) --}}
    <div class="card shadow border-0" id="printArea">
        <div class="card-body p-5">

            {{-- HEADER INVOICE --}}
            <div class="row border-bottom pb-4 mb-4">
                <div class="col-md-6">
                    <h3 class="fw-bold text-primary">SALES ORDER</h3>
                    <p class="text-muted mb-0">No: <strong>{{ $order->invoice_number }}</strong></p>
                    <p class="text-muted mb-0">Tgl: {{ $order->created_at->format('d F Y') }}</p>

                    {{-- Badge Status --}}
                    <p class="mb-0 mt-2">
                        Status Order:
                        @php
                            $badgeColor = match ($order->status) {
                                'pending_approval' => 'warning',
                                'approved' => 'primary',
                                'processed' => 'info',
                                'shipped' => 'info',
                                'delivered' => 'success',
                                'completed' => 'success',
                                'rejected' => 'danger',
                                default => 'secondary',
                            };

                            $statusLabel = match ($order->status) {
                                'pending_approval' => 'Menunggu Approval',
                                'approved' => 'Disetujui',
                                'processed' => 'Diproses Gudang',
                                'shipped' => 'Sedang Dikirim',
                                'delivered' => 'Diterima Customer',
                                'completed' => 'Selesai',
                                'rejected' => 'Ditolak',
                                default => $order->status,
                            };
                        @endphp
                        <span class="badge bg-{{ $badgeColor }} text-uppercase">{{ $statusLabel }}</span>
                    </p>
                    <p class="mb-0 mt-1">
                        Status Bayar:
                        <span
                            class="badge bg-{{ $order->payment_status == 'paid' ? 'success' : ($order->payment_status == 'partial' ? 'warning' : 'danger') }}">
                            {{ strtoupper($order->payment_status) }}
                        </span>
                    </p>
                </div>
                <div class="col-md-6 text-end">
                    <h5 class="fw-bold">Bintang Interior & Keramik</h5>
                    <p class="mb-0 text-muted">Jl. Teuku Iskandar, Ceurih, Ulee Kareng</p>
                    <p class="mb-0 text-muted">Kota Banda Aceh, Indonesia</p>
                    <p class="mb-0 text-muted">Telp: 0812-3456-7890</p>
                </div>
            </div>

            {{-- INFO TUJUAN --}}
            <div class="row mb-4">
                <div class="col-md-6">
                    <h6 class="text-uppercase text-muted small fw-bold">Kepada Yth:</h6>
                    <h5 class="fw-bold">{{ $order->customer->name }}</h5>
                    <p class="mb-0">{{ $order->customer->address }}</p>
                    <p class="mb-0">Telp: {{ $order->customer->phone ?? '-' }}</p>
                </div>
                <div class="col-md-6 text-end">
                    <h6 class="text-uppercase text-muted small fw-bold">Sales:</h6>
                    <p class="fw-bold mb-0">{{ $order->user->name }}</p>
                    <p class="small text-muted">{{ $order->user->email }}</p>
                    @if ($order->user->sales_code)
                        <p class="small text-muted fw-bold">ID: {{ $order->user->sales_code }}</p>
                    @endif
                </div>
            </div>

            {{-- TABEL ITEM --}}
            <div class="table-responsive">
                <table class="table table-bordered mb-4">
                    <thead class="table-light">
                        <tr>
                            <th class="text-center" width="5%">#</th>
                            <th>Nama Produk</th>
                            <th class="text-center">Qty</th>
                            <th class="text-end">Harga Satuan</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($order->items as $index => $item)
                            <tr>
                                <td class="text-center">{{ $index + 1 }}</td>
                                <td>
                                    {{ $item->product->name }}
                                    @if ($item->product->category)
                                        <br><small class="text-muted">{{ $item->product->category }}</small>
                                    @endif
                                </td>
                                <td class="text-center">{{ $item->quantity }}</td>
                                <td class="text-end">Rp {{ number_format($item->price, 0, ',', '.') }}</td>
                                <td class="text-end fw-bold">Rp
                                    {{ number_format($item->price * $item->quantity, 0, ',', '.') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-end fw-bold text-uppercase">Total Tagihan</td>
                            <td class="text-end fw-bold fs-5 bg-light text-primary">
                                Rp {{ number_format($order->total_price, 0, ',', '.') }}
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            {{-- CATATAN & FOOTER --}}
            @if ($order->notes)
                <div class="alert alert-light border">
                    <strong>Catatan Order:</strong> {{ $order->notes }}
                </div>
            @endif

            <div class="text-center mt-5 text-muted small">
                <p>Terima kasih telah berbelanja di Bintang Interior & Keramik.</p>
            </div>

        </div>
    </div>

    {{-- CSS UNTUK PRINT --}}
    <style>
        @media print {
            body * {
                visibility: hidden;
            }

            #printArea,
            #printArea * {
                visibility: visible;
            }

            #printArea {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                border: none !important;
                box-shadow: none !important;
            }

            .btn,
            .alert {
                display: none !important;
                /* Sembunyikan tombol & alert saat print */
            }
        }
    </style>
@endsection
