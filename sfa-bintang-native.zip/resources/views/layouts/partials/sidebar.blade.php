<nav id="sidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-start ps-3 py-3 text-decoration-none"
        href="{{ route('dashboard') }}">

        {{-- 1. LOGO AREA (Lingkaran Putih biar Kontras) --}}
        <div class="sidebar-brand-icon position-relative">
            <div class="bg-white rounded-circle shadow-sm d-flex align-items-center justify-content-center p-1"
                style="width: 42px; height: 42px;">
                {{-- Pastikan file gambar ada, kalau tidak ada, icon fallback muncul --}}
                <img src="{{ asset('images/logo.png') }}" alt="Logo" class="img-fluid"
                    style="max-height: 28px; width: auto;"
                    onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">

                {{-- Fallback Icon (Kalau gambar logo.png belum ada/rusak) --}}
                <i class="bi bi-building-fill text-primary fs-5" style="display: none;"></i>
            </div>
        </div>

        {{-- 2. TEXT AREA (Rapi & Tegas) --}}
        <div class="sidebar-brand-text ms-2 text-start d-flex flex-column justify-content-center">

            {{-- Judul Utama --}}
            <div class="fw-bold text-white text-uppercase"
                style="font-size: 0.9rem; letter-spacing: 1px; line-height: 1;">
                {{ \App\Models\Setting::where('key', 'app_name')->value('value') ?? 'SFA BINTANG' }}
            </div>

            {{-- Sub Judul --}}
            <div class="text-white-50 fst-italic mt-1" style="font-size: 0.65rem; font-weight: 300;">
                Interior System
            </div>

        </div>
    </a>

    <ul class="list-unstyled components">
        {{-- 1. DASHBOARD --}}
        <li>
            <a href="{{ route('dashboard') }}" class="{{ request()->is('dashboard') ? 'active' : '' }}">
                <span><i class="bi bi-speedometer2 me-2"></i> Dashboard</span>
            </a>
        </li>

        {{-- 2. MASTER DATA --}}
        @if (Auth::user()->role !== 'sales' || Auth::user()->role === 'sales')
            <li>
                <a href="#masterSubmenu" data-bs-toggle="collapse"
                    aria-expanded="{{ request()->is('products*', 'customers*', 'users*') ? 'true' : 'false' }}"
                    class="dropdown-toggle {{ request()->is('products*', 'customers*', 'users*') ? 'text-white' : '' }}">
                    <span><i class="bi bi-database me-2"></i> Master Data</span>
                    <i class="bi bi-chevron-down small"></i>
                </a>
                {{-- PERHATIKAN ID INI: id="masterSubmenu" --}}
                <ul class="collapse list-unstyled {{ request()->is('products*', 'customers*', 'users*') ? 'show' : '' }}"
                    id="masterSubmenu">

                    @if (in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang', 'purchase']))
                        <li><a href="{{ route('products.index') }}"
                                class="{{ request()->is('products*') ? 'active' : '' }}">Data Produk</a></li>
                    @endif

                    @if (!in_array(Auth::user()->role, ['kepala_gudang', 'admin_gudang', 'purchase']))
                        <li><a href="{{ route('customers.index') }}"
                                class="{{ request()->is('customers*') ? 'active' : '' }}">Data Customer</a></li>
                    @endif

                    @if (Auth::user()->role === 'manager_operasional')
                        <li><a href="{{ route('users.index') }}"
                                class="{{ request()->is('users*') ? 'active' : '' }}">Kelola User</a></li>
                    @endif
                </ul>
            </li>
        @endif

        {{-- 3. KUNJUNGAN --}}
        @if (in_array(Auth::user()->role, ['sales', 'manager_operasional', 'manager_bisnis']))
            <li>
                <a href="#visitSubmenu" data-bs-toggle="collapse"
                    aria-expanded="{{ request()->is('visits*') ? 'true' : 'false' }}"
                    class="dropdown-toggle {{ request()->is('visits*') ? 'text-white' : '' }}">
                    <span><i class="bi bi-geo-alt me-2"></i> Kunjungan</span>
                    <i class="bi bi-chevron-down small"></i>
                </a>
                {{-- PERHATIKAN ID INI: id="visitSubmenu" --}}
                <ul class="collapse list-unstyled {{ request()->is('visits*') ? 'show' : '' }}" id="visitSubmenu">
                    @if (Auth::user()->role === 'sales')
                        <li><a href="{{ route('visits.plan') }}"
                                class="{{ request()->is('visits/plan') ? 'active' : '' }}">Rencana Visit</a></li>
                    @endif
                    <li>
                        <a href="{{ route('visits.index') }}"
                            class="{{ request()->is('visits', 'visits/index') ? 'active' : '' }}">
                            {{ Auth::user()->role === 'sales' ? 'Riwayat Visit' : 'Monitoring Sales' }}
                        </a>
                    </li>
                </ul>
            </li>
        @endif

        {{-- 4. TRANSAKSI --}}
        <li>
            <a href="#orderSubmenu" data-bs-toggle="collapse"
                aria-expanded="{{ request()->is('orders*', 'receivables*') ? 'true' : 'false' }}"
                class="dropdown-toggle {{ request()->is('orders*', 'receivables*') ? 'text-white' : '' }}">
                <span><i class="bi bi-cart me-2"></i> Transaksi</span>
                <i class="bi bi-chevron-down small"></i>
            </a>
            <ul class="collapse list-unstyled {{ request()->is('orders*', 'receivables*') ? 'show' : '' }}"
                id="orderSubmenu">
                @if (in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis', 'sales']))
                    <li><a href="{{ route('orders.create') }}"
                            class="{{ request()->is('orders/create') ? 'active' : '' }}">Buat Order Baru</a></li>
                @endif
                <li><a href="{{ route('orders.index') }}"
                        class="{{ request()->is('orders') || (request()->is('orders/*') && !request()->is('orders/create')) ? 'active' : '' }}">Riwayat
                        Order</a></li>
                @if (in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis', 'finance', 'sales']))
                    <li><a href="{{ route('receivables.index') }}"
                            class="{{ request()->is('receivables*') ? 'active' : '' }}">Data Piutang</a></li>
                @endif
            </ul>
        </li>

        {{-- 5. SYSTEM (APPROVAL) --}}
        @php
            $isApprover = in_array(Auth::user()->role, ['manager_bisnis', 'kepala_gudang']);
            $isSuperAdmin = Auth::user()->role === 'manager_operasional';
        @endphp

        @if ($isApprover || $isSuperAdmin)
            <li>
                <hr class="dropdown-divider border-secondary my-3 mx-3 opacity-25">
                <div class="px-3 pb-2 text-muted small text-uppercase fw-bold"
                    style="font-size: 0.7rem; letter-spacing: 1px;">System</div>
            </li>

            <li class="nav-item">
                {{-- MENU UTAMA (PARENT) --}}
                <a href="#approvalSubmenu" data-bs-toggle="collapse"
                    aria-expanded="{{ request()->is('approval*') ? 'true' : 'false' }}"
                    class="dropdown-toggle d-flex align-items-center justify-content-between {{ request()->is('approval*') ? 'text-white' : '' }}">

                    {{-- Bagian Kiri: Ikon & Teks --}}
                    <div class="d-flex align-items-center">
                        <i class="bi bi-shield-check me-2"></i>
                        <span>Persetujuan</span>
                    </div>

                    {{-- Bagian Kanan: Badge Total & Panah --}}
                    <div class="d-flex align-items-center">
                        {{-- BADGE TOTAL (Muncul jika ada notif > 0) --}}
                        @if (isset($notifTotal) && $notifTotal > 0)
                            <span class="badge bg-danger rounded-pill me-2" style="font-size: 0.7rem;">
                                {{ $notifTotal }}
                            </span>
                        @endif
                        <i class="bi bi-chevron-down small"></i>
                    </div>
                </a>

                {{-- SUBMENU --}}
                <ul class="collapse list-unstyled {{ request()->is('approval*') ? 'show' : '' }}" id="approvalSubmenu">

                    @if (in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional']))
                        {{-- 1. MENU TRANSAKSI --}}
                        <li>
                            <a href="{{ route('approvals.transaksi') }}"
                                class="nav-link d-flex justify-content-between align-items-center">
                                <span>Menu Transaksi</span>
                                {{-- Badge Order --}}
                                @if (isset($notifPendingOrders) && $notifPendingOrders > 0)
                                    <span class="badge bg-danger rounded-pill" style="font-size: 0.7rem;">
                                        {{ $notifPendingOrders }}
                                    </span>
                                @endif
                            </a>
                        </li>

                        {{-- 2. BAYAR PIUTANG --}}
                        <li>
                            <a href="{{ route('approvals.piutang') }}"
                                class="nav-link d-flex justify-content-between align-items-center">
                                <span>Bayar Piutang</span>
                                {{-- Badge Piutang --}}
                                @if (isset($notifPendingPayments) && $notifPendingPayments > 0)
                                    <span class="badge bg-danger rounded-pill" style="font-size: 0.7rem;">
                                        {{ $notifPendingPayments }}
                                    </span>
                                @endif
                            </a>
                        </li>
                    @endif

                    {{-- 3. APPROVAL LAINNYA (CUSTOMER/PRODUCT) --}}
                    <li>
                        <a href="{{ route('approvals.index') }}"
                            class="nav-link d-flex justify-content-between align-items-center">
                            <span>
                                @if (in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional']))
                                    Customer
                                @elseif (in_array(Auth::user()->role, ['Kepala_gudang', 'manager_operasional']))
                                    Product
                                @endif
                            </span>

                            {{-- Badge Customer/Product (Opsional: Pastikan variabel ini ada di AppServiceProvider jika mau dipakai) --}}
                            @if (isset($notifPendingCustomers) && $notifPendingCustomers > 0)
                                <span class="badge bg-danger rounded-pill" style="font-size: 0.7rem;">
                                    {{ $notifPendingCustomers }}
                                </span>
                            @endif
                        </a>
                    </li>
                </ul>
            </li>

            @if ($isSuperAdmin)
                <li><a href="{{ route('settings.index') }}"
                        class="{{ request()->is('settings*') ? 'active' : '' }}"><span><i class="bi bi-gear me-2"></i>
                            Pengaturan</span></a></li>
            @endif
        @endif
    </ul>
</nav>
