@extends('layouts.app')

@section('title', 'Manajemen User')

@section('content')
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 fw-bold text-gray-800">Manajemen User & Sales</h1>
        <a href="{{ route('users.create') }}" class="btn btn-primary">
            <i class="bi bi-person-plus-fill"></i> Tambah User Baru
        </a>
    </div>

    <div class="card shadow border-0">
        <div class="card-body">

            {{-- @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif --}}

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nama & Kontak</th>
                            <th>Role / Jabatan</th>
                            <th>ID / Kode Sales</th>
                            <th>Terdaftar</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($users as $user)
                            <tr>
                                <td>
                                    <div class="fw-bold">{{ $user->name }}</div>
                                    <small class="text-muted d-block">{{ $user->email }}</small>
                                    @if ($user->phone)
                                        <small class="text-success"><i class="bi bi-whatsapp"></i>
                                            {{ $user->phone }}</small>
                                    @endif
                                </td>
                                <td>
                                    {{-- LOGIKA BADGE ROLE BARU --}}
                                    @switch($user->role)
                                        @case('manager_operasional')
                                            <span class="badge bg-dark">OPS MANAGER</span>
                                            @break
                                        @case('manager_bisnis')
                                            <span class="badge bg-dark">BIZ MANAGER</span>
                                            @break
                                        @case('kepala_gudang')
                                            <span class="badge bg-warning text-dark">KEPALA GUDANG</span>
                                            @break
                                        @case('admin_gudang')
                                            <span class="badge bg-warning text-dark border border-warning">ADMIN GUDANG</span>
                                            @break
                                        @case('sales')
                                            <span class="badge bg-primary">SALES</span>
                                            @break
                                        @case('finance')
                                            <span class="badge bg-success">FINANCE</span>
                                            @break
                                        @case('kasir')
                                            <span class="badge bg-success border border-success">KASIR</span>
                                            @break
                                        @case('purchase')
                                            <span class="badge bg-info text-dark">PURCHASE</span>
                                            @break
                                        @default
                                            <span class="badge bg-secondary">{{ strtoupper(str_replace('_', ' ', $user->role)) }}</span>
                                    @endswitch
                                </td>
                                <td>
                                    @if ($user->role === 'sales' && $user->sales_code)
                                        <span class="badge bg-light text-primary border border-primary font-monospace">
                                            {{ $user->sales_code }}
                                        </span>
                                    @elseif($user->role === 'sales')
                                        <span class="text-muted small fst-italic">Belum ada kode</span>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>
                                <td>{{ $user->created_at->format('d M Y') }}</td>
                                <td class="text-center">
                                    <a href="{{ route('users.edit', $user->id) }}" class="btn btn-sm btn-warning me-1">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>

                                    @if (auth()->id() != $user->id)
                                        <form action="{{ route('users.destroy', $user->id) }}" method="POST"
                                            class="d-inline"
                                            onsubmit="return confirm('Yakin hapus user ini? Data order & visitnya juga akan terhapus!');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center py-5">Belum ada data user.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                {{ $users->links() }}
            </div>
        </div>
    </div>
@endsection
