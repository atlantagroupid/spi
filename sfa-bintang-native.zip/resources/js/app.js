import './bootstrap'; // Ini bawaan Laravel (axios, dll)
import 'bootstrap';   // Ini Bootstrap 5 JS yang baru kita install
