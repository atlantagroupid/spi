
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm px-3 py-2 sticky-top">
    <div class="container-fluid">

        <?php if(auth()->guard()->check()): ?>
            <button type="button" id="sidebarCollapse" class="btn btn-outline-secondary border-0 d-md-none me-2">
                <i class="bi bi-list fs-4"></i>
            </button>
        <?php endif; ?>

        <span class="navbar-brand fw-bold fs-5 text-dark"><?php echo $__env->yieldContent('title'); ?></span>

        <div class="ms-auto d-flex align-items-center">
            <?php if(auth()->guard()->check()): ?>
                
                <div class="dropdown me-3">
                    <a class="nav-link position-relative text-secondary p-1" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-bell fs-5"></i>
                        <?php if(Auth::user()->unreadNotifications->count() > 0): ?>
                            <span
                                class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle">
                                <span class="visually-hidden">New alerts</span>
                            </span>
                        <?php endif; ?>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2"
                        style="width: 300px; max-height: 400px; overflow-y: auto;">
                        <li class="dropdown-header fw-bold bg-light py-2">Notifikasi</li>
                        <?php $__empty_1 = true; $__currentLoopData = Auth::user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li>
                                <a class="dropdown-item d-flex align-items-start p-2 border-bottom"
                                    href="<?php echo e($notification->data['link'] ?? '#'); ?>?read=<?php echo e($notification->id); ?>">
                                    <i
                                        class="bi <?php echo e($notification->data['icon'] ?? 'bi-info-circle'); ?> fs-4 text-primary me-2"></i>
                                    <div>
                                        <h6 class="mb-0 small fw-bold">
                                            <?php echo e($notification->data['title'] ?? 'Info'); ?></h6>
                                        <p class="mb-0 small text-muted text-truncate" style="max-width: 200px;">
                                            <?php echo e($notification->data['message'] ?? ''); ?></p>
                                    </div>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="text-center py-3 text-muted small">Tidak ada notifikasi.</li>
                        <?php endif; ?>
                        <?php if(Auth::user()->unreadNotifications->count() > 0): ?>
                            <li><a class="dropdown-item text-center small text-primary fw-bold py-2 bg-light"
                                    href="<?php echo e(route('notifications.markRead')); ?>">Tandai Semua Dibaca</a></li>
                        <?php endif; ?>
                    </ul>
                </div>

                
                <div class="dropdown">
                    <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle text-dark"
                        id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if(Auth::user()->photo): ?>
                            <img src="<?php echo e(asset('storage/' . Auth::user()->photo)); ?>" width="32" height="32"
                                class="rounded-circle me-2 border object-fit-cover">
                        <?php else: ?>
                            <div class="bg-primary rounded-circle text-white d-flex justify-content-center align-items-center me-2"
                                style="width: 32px; height: 32px; font-size: 0.9rem;">
                                <?php echo e(substr(Auth::user()->name, 0, 1)); ?>

                            </div>
                        <?php endif; ?>
                        <span class="d-none d-sm-inline small fw-semibold"><?php echo e(Auth::user()->name); ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2"
                        style="max-height: 400px; overflow-y: auto;">
                        <li><a class="dropdown-item small" href="<?php echo e(route('profile.edit')); ?>"><i
                                    class="bi bi-person me-2"></i>Profil Saya</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item small text-danger"><i
                                        class="bi bi-box-arrow-right me-2"></i>Logout</button>
                            </form>
                        </li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>