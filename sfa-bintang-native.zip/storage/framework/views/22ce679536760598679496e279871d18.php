<?php $__env->startSection('title', 'Pengaturan Situs'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 fw-bold text-gray-800">Pengaturan Situs</h1>
</div>

<div class="card shadow border-0">
    <div class="card-header bg-white">
        <ul class="nav nav-tabs card-header-tabs" id="settingTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active fw-bold" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button">
                    <i class="bi bi-shop me-2"></i> Identitas Toko
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link fw-bold" id="category-tab" data-bs-toggle="tab" data-bs-target="#category" type="button">
                    <i class="bi bi-tags me-2"></i> Kategori Produk
                </button>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="tab-content" id="settingTabsContent">

            
            <div class="tab-pane fade show active" id="general" role="tabpanel">
                <form action="<?php echo e(route('settings.updateGeneral')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Aplikasi (Di Header)</label>
                        <input type="text" name="app_name" class="form-control" value="<?php echo e($settings['app_name'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Perusahaan (Di Laporan/Invoice)</label>
                        <input type="text" name="company_name" class="form-control" value="<?php echo e($settings['company_name'] ?? ''); ?>">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Alamat Toko</label>
                            <textarea name="company_address" class="form-control" rows="3"><?php echo e($settings['company_address'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Nomor Telepon</label>
                            <input type="text" name="company_phone" class="form-control" value="<?php echo e($settings['company_phone'] ?? ''); ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Simpan Identitas</button>
                </form>
            </div>

            
            <div class="tab-pane fade" id="category" role="tabpanel">
                <div class="row">
                    <div class="col-md-5 mb-4">
                        <div class="card bg-light border-0">
                            <div class="card-body">
                                <h6 class="fw-bold mb-3">Tambah Kategori Baru</h6>
                                <form action="<?php echo e(route('settings.storeCategory')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group mb-3">
                                        <input type="text" name="name" class="form-control" placeholder="Contoh: Vinyl / Wallpaper" required>
                                        <button class="btn btn-success" type="submit">Tambah</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <h6 class="fw-bold mb-3">Daftar Kategori Aktif</h6>
                        <table class="table table-bordered table-hover bg-white">
                            <thead class="table-light">
                                <tr>
                                    <th>Nama Kategori</th>
                                    <th class="text-center" width="100">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cat->name); ?></td>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('settings.destroyCategory', $cat->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus kategori ini?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/settings/index.blade.php ENDPATH**/ ?>