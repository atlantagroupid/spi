<?php $__env->startSection('title', 'Detail Pembayaran'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold text-gray-800">Pembayaran Invoice: <?php echo e($order->invoice_number); ?></h1>
            <p class="text-muted mb-0">Customer: <?php echo e($order->customer->name); ?></p>
        </div>
        <div class="text-end">
            
            <?php if($order->payment_status == 'paid'): ?>
                <span class="badge bg-success fs-6 px-3 py-2">LUNAS</span>
            <?php elseif($order->payment_status == 'partial'): ?>
                <span class="badge bg-warning text-dark fs-6 px-3 py-2">CICILAN / PARSIAL</span>
            <?php else: ?>
                <span class="badge bg-danger fs-6 px-3 py-2">BELUM DIBAYAR</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-4">

            
            <div class="card shadow-sm mb-4 border-0 border-start border-4 border-primary">
                <div class="card-body">
                    <h6 class="text-muted small fw-bold mb-3">RINGKASAN TAGIHAN</h6>

                    
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-dark">Total Invoice</span>
                        <span class="fw-bold">Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></span>
                    </div>

                    
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-success"><i class="bi bi-check-circle-fill me-1"></i> Sudah Masuk</span>
                        <span class="fw-bold text-success">Rp <?php echo e(number_format($paidAmount, 0, ',', '.')); ?></span>
                    </div>

                    
                    <?php if($pendingAmount > 0): ?>
                        <div class="alert alert-warning py-2 px-2 small mb-2 border-warning">
                            <div class="d-flex justify-content-between text-warning-emphasis">
                                <span><i class="bi bi-hourglass-split me-1"></i> Menunggu Approval</span>
                                <span class="fw-bold">Rp <?php echo e(number_format($pendingAmount, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <hr>

                    
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-dark">SISA TAGIHAN</span>
                        <span class="h4 fw-bold text-danger mb-0">Rp <?php echo e(number_format($remaining, 0, ',', '.')); ?></span>
                    </div>

                    <?php if($pendingAmount > 0 && $remaining > 0): ?>
                        <small class="text-muted fst-italic mt-2 d-block text-end">
                            *Sisa tagihan akan berkurang setelah Manager menyetujui pembayaran pending.
                        </small>
                    <?php endif; ?>
                </div>
            </div>

            
            <?php if(in_array(Auth::user()->role, ['finance', 'manager_operasional']) && $remaining > 0): ?>
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold py-3">
                        <i class="bi bi-wallet2 me-2 text-primary"></i> Input Pembayaran Baru
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('receivables.store', $order->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Nominal (Rp)</label>
                                <input type="number" name="amount"
                                    class="form-control form-control-lg fw-bold text-primary" placeholder="0"
                                    max="<?php echo e($remaining); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Tanggal Terima Uang</label>
                                <input type="date" name="payment_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>"
                                    required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Metode Pembayaran</label>
                                <select name="payment_method" class="form-select">
                                    <option value="Cash">Tunai (Cash)</option>
                                    <option value="Transfer">Transfer Bank</option>
                                    <option value="Giro">Giro / Cek</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Bukti Foto / Struk</label>
                                <input type="file" name="proof_file" class="form-control" accept="image/*">
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Catatan</label>
                                <textarea name="notes" class="form-control" rows="2"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 fw-bold py-2">
                                <i class="bi bi-save me-2"></i> Simpan Pembayaran
                            </button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3">
                    <h6 class="mb-0 fw-bold">Riwayat & Status Approval</h6>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Tgl & Penginput</th>
                                <th>Nominal</th>
                                <th>Metode</th>
                                <th>Bukti</th>
                                <th class="text-center">Status Manager</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $order->paymentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold"><?php echo e(date('d M Y', strtotime($log->payment_date))); ?></div>
                                        <small class="text-muted">Input: <?php echo e($log->user->name ?? 'User'); ?></small>
                                    </td>
                                    <td>
                                        <span class="fw-bold text-dark">Rp
                                            <?php echo e(number_format($log->amount, 0, ',', '.')); ?></span>
                                    </td>
                                    <td><?php echo e($log->payment_method); ?></td>
                                    <td>
                                        <?php if($log->proof_file): ?>
                                            <a href="<?php echo e(asset('storage/payment_proofs/' . $log->proof_file)); ?>"
                                                target="_blank" class="btn btn-sm btn-outline-info">
                                                <i class="bi bi-image"></i> Lihat
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        
                                        <?php if($log->status == 'approved'): ?>
                                            <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>
                                                Diterima</span>

                                            
                                        <?php elseif($log->status == 'rejected'): ?>
                                            <span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i> Ditolak</span>

                                            
                                        <?php elseif($log->status == 'pending'): ?>
                                            <?php if(in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])): ?>
                                                <div class="btn-group shadow-sm">
                                                    <form action="<?php echo e(route('payments.approve', $log->id)); ?>" method="POST"
                                                        onsubmit="return confirm('Validasi pembayaran ini?');">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-sm btn-success" title="Terima"><i
                                                                class="bi bi-check-lg"></i></button>
                                                    </form>
                                                    <form action="<?php echo e(route('payments.reject', $log->id)); ?>"
                                                        method="POST"
                                                        onsubmit="return confirm('Tolak pembayaran ini?');">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="btn btn-sm btn-danger" title="Tolak"><i
                                                                class="bi bi-x-lg"></i></button>
                                                    </form>
                                                </div>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark"><i
                                                        class="bi bi-hourglass-split"></i> Menunggu Manager</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">Belum ada data pembayaran.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/receivables/show.blade.php ENDPATH**/ ?>