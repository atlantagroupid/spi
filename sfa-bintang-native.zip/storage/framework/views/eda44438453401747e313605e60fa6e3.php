<?php $__env->startSection('title', 'Laporan Kunjungan'); ?>

<?php $__env->startSection('content'); ?>
    
    
    
    <?php if(in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])): ?>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 fw-bold text-gray-800">Laporan & Monitoring Visit</h1>
        </div>

        
        
        


        <div class="row mb-5">

            
            <div class="col-lg-8 mb-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white py-3">
                        <h6 class="mb-0 fw-bold">
                            <i class="fas fa-shoe-prints me-2 text-primary"></i>Monitoring Kunjungan (Visit)
                        </h6>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="ps-4">Sales</th>
                                        <th class="text-center">Target</th>
                                        <th class="text-center">Realisasi</th>
                                        <th>Achievement</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $monthlyRecap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="fw-bold"><?php echo e($data['name']); ?></div>
                                                <small class="text-muted" style="font-size: 0.75rem">
                                                    Target Harian: <?php echo e($data['daily_target']); ?>

                                                </small>
                                            </td>
                                            <td class="text-center"><?php echo e($data['monthly_visit_target']); ?></td>
                                            <td class="text-center fw-bold text-primary"><?php echo e($data['actual_visit']); ?></td>
                                            <td class="pe-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="progress flex-grow-1" style="height: 6px;">
                                                        <div class="progress-bar bg-primary"
                                                            style="width: <?php echo e($data['visit_percentage']); ?>%"></div>
                                                    </div>
                                                    <span class="ms-2 small fw-bold"><?php echo e($data['visit_percentage']); ?>%</span>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4">
                <h6 class="fw-bold mb-3 text-secondary"><i class="fas fa-wallet me-2"></i>Target & Omset Sales</h6>

                <?php $__currentLoopData = $monthlyRecap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card bg-success text-white shadow-sm border-0 mb-3 position-relative overflow-hidden">

                        
                        <div class="position-absolute top-0 end-0 opacity-25" style="transform: translate(20%, -20%)">
                            <i class="fas fa-trophy fa-5x"></i>
                        </div>

                        <div class="card-body position-relative">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h6 class="fw-bold mb-0 text-white" style="font-size: 1rem;"><?php echo e($data['name']); ?></h6>
                                    <small class="text-white-50" style="font-size: 0.75rem;">Bulan Ini</small>
                                </div>

                                
                                <?php if(in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])): ?>
                                    <button
                                        class="btn btn-sm btn-light text-success fw-bold shadow-sm position-absolute top-0 end-0 m-3"
                                        style="z-index: 10;"
                                        onclick="openTargetModal('<?php echo e($data['id']); ?>', '<?php echo e($data['name']); ?>', '<?php echo e($data['daily_target']); ?>', '<?php echo e($data['target_omset']); ?>')">
                                        <i class="fas fa-edit me-1"></i> Atur Target
                                    </button>
                                <?php endif; ?>
                            </div>

                            <h4 class="fw-bold mb-0">Rp <?php echo e(number_format($data['current_omset'], 0, ',', '.')); ?></h4>
                            <div class="d-flex justify-content-between align-items-end mt-1">
                                <small class="text-white-50">Target: Rp
                                    <?php echo e(number_format($data['target_omset'], 0, ',', '.')); ?></small>
                                <small class="fw-bold text-white"><?php echo e($data['omset_percentage']); ?>%</small>
                            </div>

                            
                            <div class="progress mt-2" style="height: 4px; background-color: rgba(255,255,255,0.3);">
                                <div class="progress-bar bg-white" style="width: <?php echo e($data['omset_percentage']); ?>%"></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    
    
    

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 fw-bold text-gray-800">Laporan Kunjungan Lapangan</h1>

        
    </div>

    
    <?php if(Auth::user()->role !== 'sales'): ?>
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body py-3">
                <form action="<?php echo e(route('visits.index')); ?>" method="GET" class="row g-2 align-items-center">
                    <div class="col-auto">
                        <span class="fw-bold text-muted"><i class="bi bi-funnel"></i> Filter Sales:</span>
                    </div>
                    <div class="col-auto">
                        <select name="sales_id" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="">-- Tampilkan Semua --</option>
                            <?php $__currentLoopData = $salesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sales->id); ?>"
                                    <?php echo e(request('sales_id') == $sales->id ? 'selected' : ''); ?>>
                                    <?php echo e($sales->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <?php if(request('sales_id')): ?>
                            <a href="<?php echo e(route('visits.index')); ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-x-circle"></i> Reset
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="card shadow border-0 mb-5">
        <div class="card-body">
            <div class="table-responsive">
                
                <table class="table table-hover align-middle border-top">
                    <thead class="table-light">
                        <tr>
                            
                            <th class="py-3 text-nowrap">Tanggal</th>
                            <th class="py-3 text-nowrap">Sales</th>
                            <th class="py-3">Toko / Customer</th>
                            <th class="py-3 text-center text-nowrap">Bukti Foto</th>
                            <th class="py-3 text-center text-nowrap">Check In</th>
                            <th class="py-3 text-center text-nowrap">Check Out</th>
                            <th class="py-3 text-center text-nowrap">Durasi</th>
                            <th class="py-3 text-center text-nowrap">Lokasi</th>
                            <th class="py-3">Laporan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                
                                <td class="text-nowrap">
                                    <div class="fw-bold text-dark"><?php echo e($visit->created_at->format('d M Y')); ?></div>
                                    <small class="text-muted"><?php echo e($visit->created_at->format('H:i')); ?> WIB</small>
                                </td>

                                
                                <td class="fw-bold text-secondary">
                                    <?php echo e($visit->user->name); ?>

                                </td>

                                
                                <td style="min-width: 200px;">
                                    <div class="fw-bold text-dark"><?php echo e($visit->customer->name); ?></div>
                                    <small class="text-muted d-block text-truncate" style="max-width: 250px;">
                                        <?php echo e($visit->customer->address); ?>

                                    </small>
                                </td>

                                
                                <td class="text-center">
                                    <?php if($visit->photo_path): ?>
                                        <a href="<?php echo e(asset('storage/' . $visit->photo_path)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('storage/' . $visit->photo_path)); ?>"
                                                class="rounded border shadow-sm"
                                                style="width: 60px; height: 60px; object-fit: cover;">
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="text-center fw-bold text-primary">
                                    <?php echo e($visit->check_in_time->format('H:i')); ?>

                                </td>

                                
                                <td class="text-center">
                                    <?php if($visit->check_out_time): ?>
                                        
                                        <div class="d-flex flex-column align-items-center">
                                            <span class="fw-bold">
                                                <?php echo e(\Carbon\Carbon::parse($visit->check_out_time)->format('H:i')); ?>

                                            </span>

                                            
                                            <?php if(str_contains($visit->notes, '[SYSTEM]: Auto Cutoff')): ?>
                                                <span class="badge bg-secondary mt-1" style="font-size: 0.65rem;"
                                                    data-bs-toggle="tooltip"
                                                    title="Kunjungan dihentikan otomatis oleh sistem karena > 2 jam">
                                                    <i class="bi bi-robot"></i> Auto Close
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        
                                        <?php if($visit->created_at->isToday()): ?>
                                            
                                            <?php if(Auth::id() == $visit->user_id): ?>
                                                <a href="<?php echo e(route('visits.perform', $visit->id)); ?>"
                                                    class="btn btn-warning btn-sm fw-bold">
                                                    Check Out
                                                </a>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Sedang Visit</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            
                                            <span class="badge bg-danger">Proses Cutoff...</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="text-center">
                                    <?php if($visit->check_out_time): ?>
                                        <span class="badge bg-success">
                                            <?php echo e(round($visit->check_in_time->diffInMinutes($visit->check_out_time))); ?> Menit
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">
                                            Berjalan <?php echo e(round($visit->check_in_time->diffInMinutes(now()))); ?> Menit
                                        </span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="text-center">
                                    <?php if($visit->latitude && $visit->longitude): ?>
                                        
                                        <a href="https://www.google.com/maps?q=<?php echo e($visit->latitude); ?>,<?php echo e($visit->longitude); ?>"
                                            target="_blank" class="btn btn-sm btn-outline-success">
                                            <i class="bi bi-map"></i> Lihat Peta
                                        </a>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No GPS</span>
                                    <?php endif; ?>
                                </td>

                                
                                <td style="min-width: 200px;">
                                    
                                    <span class="text-muted fst-italic d-block mb-1">
                                        "<?php echo e(Str::limit($visit->notes, 50)); ?>"
                                    </span>

                                    
                                    <?php if(strlen($visit->notes) > 50): ?>
                                        <button type="button"
                                            class="btn btn-link p-0 text-primary fw-bold text-decoration-none"
                                            style="font-size: 0.75rem;"
                                            onclick="showNoteModal(`<?php echo e(str_replace(["\r", "\n"], ' ', addslashes($visit->notes))); ?>`)">
                                            Baca Selengkapnya
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-5 text-muted">
                                    <img src="https://img.freepik.com/free-vector/no-data-concept-illustration_114360-536.jpg"
                                        width="100" class="mb-3 opacity-50">
                                    <p>Belum ada data kunjungan.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($visits->links()); ?>

            </div>
        </div>
    </div>

    
    
    

    
    <div class="modal fade" id="targetModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold">Atur Target Sales</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="<?php echo e(route('visits.updateTarget')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="user_id" id="modalUserId">

                        
                        <div class="mb-3">
                            <label class="form-label">Nama Sales</label>
                            <input type="text" class="form-control bg-light" id="modalUserName" readonly>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Target Visit Harian</label>
                            <div class="input-group">
                                <input type="number" name="daily_visit_target" id="modalUserTargetVisit"
                                    class="form-control" min="1" required>
                                <span class="input-group-text">Kunjungan / Hari</span>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-success">Target Omset Bulanan</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" name="sales_target" id="modalUserTargetOmset" class="form-control"
                                    min="0" required>
                            </div>
                            <small class="text-muted">Masukkan angka tanpa titik (Contoh: 50000000)</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Target</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
<div class="modal fade" id="noteModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h6 class="modal-title fw-bold"><i class="bi bi-journal-text me-2"></i>Catatan Kunjungan</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p id="fullNoteContent" class="mb-0 text-secondary" style="white-space: pre-wrap;"></p>
            </div>
            <div class="modal-footer py-1">
                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script>
    function showNoteModal(noteContent) {
        // 1. Isi teks ke dalam modal
        document.getElementById('fullNoteContent').innerText = noteContent;

        // 2. Tampilkan modal
        new bootstrap.Modal(document.getElementById('noteModal')).show();
    }
</script>

    
    
    <script>
        function openTargetModal(id, name, targetVisit, targetOmset) {
            // Isi data ke dalam form modal
            document.getElementById('modalUserId').value = id;
            document.getElementById('modalUserName').value = name;
            document.getElementById('modalUserTargetVisit').value = targetVisit;
            document.getElementById('modalUserTargetOmset').value = targetOmset;

            // Buka Modal
            var myModal = new bootstrap.Modal(document.getElementById('targetModal'));
            myModal.show();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/visits/index.blade.php ENDPATH**/ ?>