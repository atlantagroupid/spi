<style>
    body {
        overflow-x: hidden;
        font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        background-color: #f4f6f9;
    }

    #wrapper {
        display: flex;
        width: 100%;
        align-items: stretch;
    }

    /* --- SIDEBAR STYLE --- */
    #sidebar {
        min-width: 260px;
        max-width: 260px;
        min-height: 100vh;
        background: #212529;
        color: #fff;
        transition: all 0.3s;
        z-index: 1000;
    }

    #sidebar .sidebar-header {
        padding: 20px;
        background: #1a1e21;
        border-bottom: 1px solid #373b3e;
    }

    #sidebar ul.components {
        padding: 15px 0;
    }

    /* Link Menu Utama */
    #sidebar ul li a {
        padding: 12px 25px;
        font-size: 0.95rem;
        display: flex;
        /* Biar icon dan teks sejajar */
        align-items: center;
        color: #adb5bd;
        text-decoration: none;
        border-left: 4px solid transparent;
        transition: 0.2s;
    }

    #sidebar ul li a:hover {
        color: #fff;
        background: #2c3034;
    }

    #sidebar ul li a.active {
        color: #fff;
        background: #343a40;
        border-left: 4px solid #0d6efd;
    }

    /* --- PERBAIKAN DROPDOWN (HILANGKAN PANAH GANDA) --- */
    /* 1. Matikan panah bawaan bootstrap */
    #sidebar ul li a.dropdown-toggle::after {
        display: none !important;
    }

    /* 2. Atur posisi panah manual kita */
    #sidebar ul li a.dropdown-toggle {
        justify-content: space-between;
        /* Teks kiri, Panah kanan */
    }

    /* 3. Animasi Panah Berputar saat diklik */
    #sidebar ul li a.dropdown-toggle[aria-expanded="true"] .bi-chevron-down {
        transform: rotate(180deg);
        transition: transform 0.3s;
    }

    #sidebar ul li a.dropdown-toggle[aria-expanded="false"] .bi-chevron-down {
        transform: rotate(0deg);
        transition: transform 0.3s;
    }

    /* --- SUBMENU STYLE --- */
    #sidebar ul ul {
        background: #151719;
        /* Warna lebih gelap untuk submenu */
    }

    #sidebar ul ul a {
        font-size: 0.9em !important;
        padding-left: 55px !important;
        /* Indentasi ke dalam */
        padding-top: 10px;
        padding-bottom: 10px;
        background: transparent !important;
        border-left: none !important;
    }

    #sidebar ul ul a:hover {
        color: #0d6efd !important;
        /* Biru saat hover submenu */
    }

    #sidebar ul ul a.active {
        color: #0d6efd !important;
        font-weight: bold;
        background: transparent !important;
    }

    /* --- CONTENT & RESPONSIVE --- */
    #content {
        width: 100%;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    @media (max-width: 768px) {
        #sidebar {
            margin-left: -260px;
            position: fixed;
            height: 100%;
        }

        #sidebar.active {
            margin-left: 0;
        }

        .overlay {
            display: none;
            position: fixed;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.5);
            z-index: 998;
        }

        .overlay.active {
            display: block;
        }
    }

    /* --- TAMBAHAN KHUSUS MOBILE (RESPONSIVE) --- */
    @media (max-width: 576px) {

        /* 1. Perbaiki Dropdown Notifikasi di HP */
        .dropdown-menu {
            width: 90vw !important;
            /* Lebar 90% dari layar HP */
            max-width: 350px !important;
            right: -10px !important;
            /* Geser dikit biar gak mepet kanan */
            left: auto !important;
        }

        /* 2. Font ukuran kecil di HP biar muat */
        .navbar-brand {
            font-size: 1.1rem !important;
        }

        /* 3. Padding konten dikurangi biar lega */
        #content .container-fluid {
            padding: 10px !important;
            /* Di PC 24px, di HP 10px aja */
        }

        /* 4. Sembunyikan nama user di navbar HP (cuma avatar) */
        .navbar .d-none.d-sm-inline {
            display: none !important;
        }
    }
</style>
<?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/layouts/partials/styles.blade.php ENDPATH**/ ?>