<?php $__env->startSection('title', 'Manajemen User'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 fw-bold text-gray-800">Manajemen User & Sales</h1>
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
            <i class="bi bi-person-plus-fill"></i> Tambah User Baru
        </a>
    </div>

    <div class="card shadow border-0">
        <div class="card-body">

            

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nama & Kontak</th>
                            <th>Role / Jabatan</th>
                            <th>ID / Kode Sales</th>
                            <th>Terdaftar</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="fw-bold"><?php echo e($user->name); ?></div>
                                    <small class="text-muted d-block"><?php echo e($user->email); ?></small>
                                    <?php if($user->phone): ?>
                                        <small class="text-success"><i class="bi bi-whatsapp"></i>
                                            <?php echo e($user->phone); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    
                                    <?php switch($user->role):
                                        case ('manager_operasional'): ?>
                                            <span class="badge bg-dark">OPS MANAGER</span>
                                            <?php break; ?>
                                        <?php case ('manager_bisnis'): ?>
                                            <span class="badge bg-dark">BIZ MANAGER</span>
                                            <?php break; ?>
                                        <?php case ('kepala_gudang'): ?>
                                            <span class="badge bg-warning text-dark">KEPALA GUDANG</span>
                                            <?php break; ?>
                                        <?php case ('admin_gudang'): ?>
                                            <span class="badge bg-warning text-dark border border-warning">ADMIN GUDANG</span>
                                            <?php break; ?>
                                        <?php case ('sales'): ?>
                                            <span class="badge bg-primary">SALES</span>
                                            <?php break; ?>
                                        <?php case ('finance'): ?>
                                            <span class="badge bg-success">FINANCE</span>
                                            <?php break; ?>
                                        <?php case ('kasir'): ?>
                                            <span class="badge bg-success border border-success">KASIR</span>
                                            <?php break; ?>
                                        <?php case ('purchase'): ?>
                                            <span class="badge bg-info text-dark">PURCHASE</span>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <span class="badge bg-secondary"><?php echo e(strtoupper(str_replace('_', ' ', $user->role))); ?></span>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <?php if($user->role === 'sales' && $user->sales_code): ?>
                                        <span class="badge bg-light text-primary border border-primary font-monospace">
                                            <?php echo e($user->sales_code); ?>

                                        </span>
                                    <?php elseif($user->role === 'sales'): ?>
                                        <span class="text-muted small fst-italic">Belum ada kode</span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-sm btn-warning me-1">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>

                                    <?php if(auth()->id() != $user->id): ?>
                                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST"
                                            class="d-inline"
                                            onsubmit="return confirm('Yakin hapus user ini? Data order & visitnya juga akan terhapus!');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5">Belum ada data user.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/users/index.blade.php ENDPATH**/ ?>