<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SFA Bintang Interior</title>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo.png')); ?>">
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;

            /* BACKGROUND GAMBAR INTERIOR (Ganti URL ini dengan foto toko Anda jika mau) */
            background: url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=2053&auto=format&fit=crop') no-repeat center center/cover;

            /* Overlay Hitam Transparan (Biar tulisan terbaca) */
            position: relative;
        }

        /* Lapisan Gelap di atas Gambar */
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
            /* Gelap 40% */
            z-index: 0;
        }

        /* EFEK KACA (GLASSMORPHISM) */
        .glass-card {
            position: relative;
            z-index: 1;
            background: rgba(255, 255, 255, 0.15);
            /* Putih Transparan */
            backdrop-filter: blur(15px);
            /* Efek Buram di belakangnya */
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            /* Garis tepi tipis */
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
            max-width: 450px;
            width: 100%;
            color: #fff;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 0.95rem;
        }

        .form-control:focus {
            background: #fff;
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.3);
        }

        .btn-login {
            background: #0d6efd;
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: 0.3s;
        }

        .btn-login:hover {
            background: #0b5ed7;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.4);
        }

        .logo-icon {
            font-size: 3rem;
            color: #fff;
            text-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        .drop-shadow {
            filter: drop-shadow(0 5px 5px rgba(0, 0, 0, 0.3));
        }

        .text-shadow {
            text-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>

<body>

    <div class="glass-card text-center">

        
        <div class="mb-4">
            
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo Bintang Interior" class="img-fluid drop-shadow"
                style="max-height: 80px; width: auto;">
            
        </div>

        

        

        

        <h3 class="fw-bold mb-1">SFA Bintang</h3>
        <p class="mb-4 opacity-75 small">Interior & Keramik System</p>

        
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            
            <div class="mb-3 text-start">
                <label class="form-label small ms-1 opacity-75">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text border-0 rounded-start-3 bg-white text-secondary">
                        <i class="bi bi-envelope"></i>
                    </span>
                    <input type="email" name="email"
                        class="form-control rounded-end-3 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="nama@bintang.com" value="<?php echo e(old('email')); ?>" required autofocus>
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-warning small mt-1 d-block text-shadow">
                        <i class="bi bi-exclamation-circle"></i> <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-4 text-start">
                <label class="form-label small ms-1 opacity-75">Password</label>
                <div class="input-group">
                    <span class="input-group-text border-0 rounded-start-3 bg-white text-secondary">
                        <i class="bi bi-lock"></i>
                    </span>
                    <input type="password" name="password"
                        class="form-control rounded-end-3 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="••••••••" required>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-warning small mt-1 d-block text-shadow">
                        <i class="bi bi-exclamation-circle"></i> <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-4 d-flex justify-content-between align-items-center">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember"
                        <?php echo e(old('remember') ? 'checked' : ''); ?>>
                    <label class="form-check-label small" for="remember">
                        Ingat Saya
                    </label>
                </div>
                <?php if(Route::has('password.request')): ?>
                    
                <?php endif; ?>
            </div>

            
            <button type="submit" class="btn btn-primary w-100 btn-login shadow-sm">
                MASUK APLIKASI <i class="bi bi-box-arrow-in-right ms-2"></i>
            </button>
        </form>

        <div class="mt-4 pt-3 border-top border-white border-opacity-25">
            <small class="opacity-50" style="font-size: 0.75rem;">
                &copy; <?php echo e(date('Y')); ?> CV. Bintang Interior & Keramik
            </small>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/auth/login.blade.php ENDPATH**/ ?>