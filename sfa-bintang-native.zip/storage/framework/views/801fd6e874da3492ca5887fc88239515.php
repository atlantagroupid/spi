<nav id="sidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-start ps-3 py-3 text-decoration-none"
        href="<?php echo e(route('dashboard')); ?>">

        
        <div class="sidebar-brand-icon position-relative">
            <div class="bg-white rounded-circle shadow-sm d-flex align-items-center justify-content-center p-1"
                style="width: 42px; height: 42px;">
                
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" class="img-fluid"
                    style="max-height: 28px; width: auto;"
                    onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">

                
                <i class="bi bi-building-fill text-primary fs-5" style="display: none;"></i>
            </div>
        </div>

        
        <div class="sidebar-brand-text ms-2 text-start d-flex flex-column justify-content-center">

            
            <div class="fw-bold text-white text-uppercase"
                style="font-size: 0.9rem; letter-spacing: 1px; line-height: 1;">
                <?php echo e(\App\Models\Setting::where('key', 'app_name')->value('value') ?? 'SFA BINTANG'); ?>

            </div>

            
            <div class="text-white-50 fst-italic mt-1" style="font-size: 0.65rem; font-weight: 300;">
                Interior System
            </div>

        </div>
    </a>

    <ul class="list-unstyled components">
        
        <li>
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                <span><i class="bi bi-speedometer2 me-2"></i> Dashboard</span>
            </a>
        </li>

        
        <?php if(Auth::user()->role !== 'sales' || Auth::user()->role === 'sales'): ?>
            <li>
                <a href="#masterSubmenu" data-bs-toggle="collapse"
                    aria-expanded="<?php echo e(request()->is('products*', 'customers*', 'users*') ? 'true' : 'false'); ?>"
                    class="dropdown-toggle <?php echo e(request()->is('products*', 'customers*', 'users*') ? 'text-white' : ''); ?>">
                    <span><i class="bi bi-database me-2"></i> Master Data</span>
                    <i class="bi bi-chevron-down small"></i>
                </a>
                
                <ul class="collapse list-unstyled <?php echo e(request()->is('products*', 'customers*', 'users*') ? 'show' : ''); ?>"
                    id="masterSubmenu">

                    <?php if(in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang', 'purchase'])): ?>
                        <li><a href="<?php echo e(route('products.index')); ?>"
                                class="<?php echo e(request()->is('products*') ? 'active' : ''); ?>">Data Produk</a></li>
                    <?php endif; ?>

                    <?php if(!in_array(Auth::user()->role, ['kepala_gudang', 'admin_gudang', 'purchase'])): ?>
                        <li><a href="<?php echo e(route('customers.index')); ?>"
                                class="<?php echo e(request()->is('customers*') ? 'active' : ''); ?>">Data Customer</a></li>
                    <?php endif; ?>

                    <?php if(Auth::user()->role === 'manager_operasional'): ?>
                        <li><a href="<?php echo e(route('users.index')); ?>"
                                class="<?php echo e(request()->is('users*') ? 'active' : ''); ?>">Kelola User</a></li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>

        
        <?php if(in_array(Auth::user()->role, ['sales', 'manager_operasional', 'manager_bisnis'])): ?>
            <li>
                <a href="#visitSubmenu" data-bs-toggle="collapse"
                    aria-expanded="<?php echo e(request()->is('visits*') ? 'true' : 'false'); ?>"
                    class="dropdown-toggle <?php echo e(request()->is('visits*') ? 'text-white' : ''); ?>">
                    <span><i class="bi bi-geo-alt me-2"></i> Kunjungan</span>
                    <i class="bi bi-chevron-down small"></i>
                </a>
                
                <ul class="collapse list-unstyled <?php echo e(request()->is('visits*') ? 'show' : ''); ?>" id="visitSubmenu">
                    <?php if(Auth::user()->role === 'sales'): ?>
                        <li><a href="<?php echo e(route('visits.plan')); ?>"
                                class="<?php echo e(request()->is('visits/plan') ? 'active' : ''); ?>">Rencana Visit</a></li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('visits.index')); ?>"
                            class="<?php echo e(request()->is('visits', 'visits/index') ? 'active' : ''); ?>">
                            <?php echo e(Auth::user()->role === 'sales' ? 'Riwayat Visit' : 'Monitoring Sales'); ?>

                        </a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>

        
        <li>
            <a href="#orderSubmenu" data-bs-toggle="collapse"
                aria-expanded="<?php echo e(request()->is('orders*', 'receivables*') ? 'true' : 'false'); ?>"
                class="dropdown-toggle <?php echo e(request()->is('orders*', 'receivables*') ? 'text-white' : ''); ?>">
                <span><i class="bi bi-cart me-2"></i> Transaksi</span>
                <i class="bi bi-chevron-down small"></i>
            </a>
            <ul class="collapse list-unstyled <?php echo e(request()->is('orders*', 'receivables*') ? 'show' : ''); ?>"
                id="orderSubmenu">
                <?php if(in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis', 'sales'])): ?>
                    <li><a href="<?php echo e(route('orders.create')); ?>"
                            class="<?php echo e(request()->is('orders/create') ? 'active' : ''); ?>">Buat Order Baru</a></li>
                <?php endif; ?>
                <li><a href="<?php echo e(route('orders.index')); ?>"
                        class="<?php echo e(request()->is('orders') || (request()->is('orders/*') && !request()->is('orders/create')) ? 'active' : ''); ?>">Riwayat
                        Order</a></li>
                <?php if(in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis', 'finance', 'sales'])): ?>
                    <li><a href="<?php echo e(route('receivables.index')); ?>"
                            class="<?php echo e(request()->is('receivables*') ? 'active' : ''); ?>">Data Piutang</a></li>
                <?php endif; ?>
            </ul>
        </li>

        
        <?php
            $isApprover = in_array(Auth::user()->role, ['manager_bisnis', 'kepala_gudang']);
            $isSuperAdmin = Auth::user()->role === 'manager_operasional';
        ?>

        <?php if($isApprover || $isSuperAdmin): ?>
            <li>
                <hr class="dropdown-divider border-secondary my-3 mx-3 opacity-25">
                <div class="px-3 pb-2 text-muted small text-uppercase fw-bold"
                    style="font-size: 0.7rem; letter-spacing: 1px;">System</div>
            </li>

            <li class="nav-item">
                
                <a href="#approvalSubmenu" data-bs-toggle="collapse"
                    aria-expanded="<?php echo e(request()->is('approval*') ? 'true' : 'false'); ?>"
                    class="dropdown-toggle d-flex align-items-center justify-content-between <?php echo e(request()->is('approval*') ? 'text-white' : ''); ?>">

                    
                    <div class="d-flex align-items-center">
                        <i class="bi bi-shield-check me-2"></i>
                        <span>Persetujuan</span>
                    </div>

                    
                    <div class="d-flex align-items-center">
                        
                        <?php if(isset($notifTotal) && $notifTotal > 0): ?>
                            <span class="badge bg-danger rounded-pill me-2" style="font-size: 0.7rem;">
                                <?php echo e($notifTotal); ?>

                            </span>
                        <?php endif; ?>
                        <i class="bi bi-chevron-down small"></i>
                    </div>
                </a>

                
                <ul class="collapse list-unstyled <?php echo e(request()->is('approval*') ? 'show' : ''); ?>" id="approvalSubmenu">

                    <?php if(in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])): ?>
                        
                        <li>
                            <a href="<?php echo e(route('approvals.transaksi')); ?>"
                                class="nav-link d-flex justify-content-between align-items-center">
                                <span>Menu Transaksi</span>
                                
                                <?php if(isset($notifPendingOrders) && $notifPendingOrders > 0): ?>
                                    <span class="badge bg-danger rounded-pill" style="font-size: 0.7rem;">
                                        <?php echo e($notifPendingOrders); ?>

                                    </span>
                                <?php endif; ?>
                            </a>
                        </li>

                        
                        <li>
                            <a href="<?php echo e(route('approvals.piutang')); ?>"
                                class="nav-link d-flex justify-content-between align-items-center">
                                <span>Bayar Piutang</span>
                                
                                <?php if(isset($notifPendingPayments) && $notifPendingPayments > 0): ?>
                                    <span class="badge bg-danger rounded-pill" style="font-size: 0.7rem;">
                                        <?php echo e($notifPendingPayments); ?>

                                    </span>
                                <?php endif; ?>
                            </a>
                        </li>
                    <?php endif; ?>

                    
                    <li>
                        <a href="<?php echo e(route('approvals.index')); ?>"
                            class="nav-link d-flex justify-content-between align-items-center">
                            <span>
                                <?php if(in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])): ?>
                                    Customer
                                <?php elseif(in_array(Auth::user()->role, ['Kepala_gudang', 'manager_operasional'])): ?>
                                    Product
                                <?php endif; ?>
                            </span>

                            
                            <?php if(isset($notifPendingCustomers) && $notifPendingCustomers > 0): ?>
                                <span class="badge bg-danger rounded-pill" style="font-size: 0.7rem;">
                                    <?php echo e($notifPendingCustomers); ?>

                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </li>

            <?php if($isSuperAdmin): ?>
                <li><a href="<?php echo e(route('settings.index')); ?>"
                        class="<?php echo e(request()->is('settings*') ? 'active' : ''); ?>"><span><i class="bi bi-gear me-2"></i>
                            Pengaturan</span></a></li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>