<?php $__env->startSection('title', 'Data Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
        <h1 class="h3 mb-0 text-gray-800">Data Produk & Stok</h1>

        
        <div class="mt-1 small text-muted">
            <span class="me-3">
                <i class="bi bi-cash-stack me-1"></i> Total Aset:
                <span class="fw-bold text-success">
                    Rp <?php echo e(number_format($totalAsset ?? 0, 0, ',', '.')); ?>

                </span>
            </span>
            <span>
                <i class="bi bi-box-seam me-1"></i> Total Stok:
                <span class="fw-bold text-primary">
                    <?php echo e(number_format($totalStock ?? 0, 0, ',', '.')); ?> Unit
                </span>
            </span>
        </div>

    </div>
        

        <?php if(in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang'])): ?>
            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary shadow-sm">
                <i class="bi bi-plus-lg me-2"></i> Tambah Produk
            </a>
        <?php endif; ?>
    </div>

    
    <?php if(in_array(Auth::user()->role, ['purchase', 'manager_operasional', 'kepala_gudang'])): ?>
        <?php if(isset($lowStockProducts) && $lowStockProducts->count() > 0): ?>
            <div class="card border-warning mb-4 shadow-sm">
                <div
                    class="card-header bg-warning bg-opacity-10 fw-bold text-warning-emphasis d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-exclamation-triangle-fill me-2"></i> Perlu Restock (Stok Menipis)</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm mb-0 align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3">Produk</th>
                                    <th class="text-center">Sisa Stok</th>
                                    <th>Status Pemesanan</th>
                                    <th class="text-end pe-3">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="ps-3 fw-bold"><?php echo e($item->name); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-danger"><?php echo e($item->stock); ?> Unit</span>
                                        </td>
                                        <td>
                                            <?php if($item->restock_date): ?>
                                                <span class="badge bg-info text-dark border border-info">
                                                    <i class="bi bi-calendar-check me-1"></i>
                                                    Dipesan: <?php echo e(date('d/m/Y', strtotime($item->restock_date))); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary opacity-50">Belum Pesan</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end pe-3">
                                            
                                            <button class="btn btn-sm btn-outline-primary"
                                                onclick="openRestockModal('<?php echo e($item->id); ?>', '<?php echo e($item->name); ?>', '<?php echo e($item->restock_date); ?>')">
                                                <i class="bi bi-pencil-square"></i> Update Info
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    
    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-body">
            <form action="<?php echo e(route('products.index')); ?>" method="GET" class="row g-2">
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama produk..."
                        value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-3">
                    <select name="category" class="form-select" onchange="this.form.submit()">
                        <option value="">- Semua Kategori -</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat); ?>" <?php echo e(request('category') == $cat ? 'selected' : ''); ?>>
                                <?php echo e($cat); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="is_discount" class="form-select" onchange="this.form.submit()">
                        <option value="">- Semua Harga -</option>
                        <option value="1" <?php echo e(request('is_discount') == '1' ? 'selected' : ''); ?>>🏷️ Diskon</option>
                    </select>
                </div>
                
                <div class="col-md-2 d-flex gap-1">
                    
                    <button type="submit" class="btn btn-primary flex-fill">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>

                    
                    
                    <?php if(request('search') || request('category') || request('price_order')): ?>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger" title="Reset Filter">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    <?php else: ?>
                        
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-light border" title="Refresh Data">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3" width="80">Gambar</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>

                            
                            <?php if(Auth::user()->role === 'purchase'): ?>
                                
                                <th>Harga Normal</th>
                                <th style="width: 200px;" class="text-danger bg-danger bg-opacity-10">Set Harga Diskon</th>
                            <?php else: ?>
                                
                                <th>Harga Satuan</th>
                            <?php endif; ?>

                            <th class="text-center">Stok</th>

                            
                            <?php if(in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang'])): ?>
                                <th class="text-center pe-4" width="100">Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center" style="width: 80px;">
                                    <?php if($product->image): ?>
                                        
                                        <a href="#" data-bs-toggle="modal"
                                            data-bs-target="#imgModal<?php echo e($product->id); ?>">
                                            <img src="<?php echo e(asset('storage/products/' . $product->image)); ?>"
                                                class="rounded border shadow-sm" width="50" height="50"
                                                style="object-fit: cover; cursor: pointer;" alt="Produk">
                                        </a>

                                        
                                        <div class="modal fade" id="imgModal<?php echo e($product->id); ?>" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h6 class="modal-title fw-bold"><?php echo e($product->name); ?></h6>
                                                        <button type="button" class="btn-close"
                                                            data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body text-center p-0 bg-light">
                                                        <img src="<?php echo e(asset('storage/products/' . $product->image)); ?>"
                                                            class="img-fluid" style="max-height: 500px;">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        
                                        <img src="https://via.placeholder.com/50?text=No+Img"
                                            class="rounded border opacity-50" width="50" height="50">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo e($product->name); ?></div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo e($product->category); ?></span>
                                </td>

                                
                                <?php if(Auth::user()->role === 'purchase'): ?>
                                    
                                    <td>
                                        <span class="fw-bold text-dark">Rp
                                            <?php echo e(number_format($product->price, 0, ',', '.')); ?></span>
                                    </td>
                                    <td class="bg-danger bg-opacity-10">
                                        
                                        <form action="<?php echo e(route('products.updateDiscount', $product->id)); ?>"
                                            method="POST" class="d-flex gap-1">
                                            <?php echo csrf_field(); ?>
                                            <input type="number" name="discount_price"
                                                class="form-control form-control-sm border-danger text-danger fw-bold"
                                                value="<?php echo e($product->discount_price == 0 ? '' : $product->discount_price); ?>"
                                                placeholder="No Disc">
                                            <button type="submit" class="btn btn-sm btn-danger shadow-sm"
                                                title="Simpan Diskon">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </form>
                                    </td>
                                <?php else: ?>
                                    
                                    <td>
                                        <?php if($product->discount_price && $product->discount_price > 0): ?>
                                            <div class="text-decoration-line-through text-muted small">
                                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                            </div>
                                            <div class="fw-bold text-danger">
                                                Rp <?php echo e(number_format($product->discount_price, 0, ',', '.')); ?>

                                            </div>
                                        <?php else: ?>
                                            <div class="fw-bold text-primary">
                                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>

                                <td class="text-center">
                                    <?php if($product->stock <= 10): ?>
                                        <span class="badge bg-warning text-dark"><?php echo e($product->stock); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-success"><?php echo e($product->stock); ?></span>
                                    <?php endif; ?>
                                </td>

                                <?php if(in_array(Auth::user()->role, ['manager_operasional', 'kepala_gudang', 'admin_gudang'])): ?>
                                    <td class="text-center" style="white-space: nowrap;">
                                        
                                        <div class="d-flex justify-content-center align-items-center gap-1">

                                            
                                            <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                                class="btn btn-sm btn-outline-primary" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>

                                            
                                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST"
                                                class="d-inline m-0">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger shadow-sm"
                                                    onclick="confirmSubmit(event, 'Hapus Produk?', 'Data yang dihapus tidak bisa dikembalikan!')"
                                                    title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>

                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">Tidak ada data.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="p-3"><?php echo e($products->links()); ?></div>
        </div>
    </div>

    
    <div class="modal fade" id="restockModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-warning bg-opacity-25">
                    <h5 class="modal-title fw-bold">Update Info Restock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="restockForm" action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p>Barang: <strong id="modalProductName"></strong></p>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Pemesanan Barang (PO ke Pabrik)</label>
                            <input type="date" name="restock_date" id="modalRestockDate" class="form-control"
                                required>
                            <small class="text-muted">Isi tanggal kapan barang dipesan.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Info</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openRestockModal(id, name, date) {
            document.getElementById('modalProductName').innerText = name;
            document.getElementById('modalRestockDate').value = date;

            // Set Action Form Dinamis
            let url = "<?php echo e(route('products.updateRestock', ':id')); ?>";
            url = url.replace(':id', id);
            document.getElementById('restockForm').action = url;

            new bootstrap.Modal(document.getElementById('restockModal')).show();
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/products/index.blade.php ENDPATH**/ ?>