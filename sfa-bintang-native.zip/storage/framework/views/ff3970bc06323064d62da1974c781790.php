<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Persetujuan Perubahan Data</h1>
        <br>

        
        

        <div class="card mb-4 shadow-sm border-0">
            <div class="card-header bg-warning text-dark fw-bold">
                <i class="bi bi-hourglass-split me-1"></i> Daftar Pending Approval
            </div>
            <div class="card-body">
                <?php if($approvals->isEmpty()): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-check2-circle fs-1 text-success mb-3" style="font-size: 3rem;"></i>
                        <h5 class="text-muted">Semua Beres!</h5>
                        <p class="text-muted small">Tidak ada pengajuan yang perlu diproses saat ini.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Pengaju</th>
                                    <th>Tipe Data</th>
                                    <th>Jenis Aksi</th>
                                    <th style="min-width: 250px;">Detail Info</th>
                                    <th class="text-end" style="min-width: 180px;">Keputusan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $approvals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td class="small text-muted">
                                            <?php echo e($app->created_at->format('d M Y')); ?><br>
                                            <?php echo e($app->created_at->format('H:i')); ?>

                                        </td>

                                        
                                        <td>
                                            <div class="fw-bold"><?php echo e($app->requester->name ?? 'Unknown'); ?></div>
                                            <small class="badge bg-light text-dark border border-secondary text-capitalize">
                                                <?php echo e(str_replace('_', ' ', $app->requester->role ?? '-')); ?>

                                            </small>
                                        </td>

                                        
                                        <td>
                                            <?php if(str_contains($app->model_type, 'Order')): ?>
                                                <span class="badge bg-primary text-white"><i
                                                        class="bi bi-cart-fill me-1"></i> Order Baru</span>
                                                <span
                                                    class="badge bg-secondary"><?php echo e(class_basename($app->model_type)); ?></span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            <?php if($app->action == 'delete'): ?>
                                                <span class="badge bg-danger">HAPUS DATA</span>
                                            <?php elseif($app->action == 'create'): ?>
                                                <span class="badge bg-success">DATA BARU</span>
                                            <?php elseif($app->action == 'approve_payment'): ?>
                                                <span class="badge bg-success">TERIMA BAYAR</span>
                                            <?php elseif($app->action == 'approve_order'): ?>
                                                <span class="badge bg-primary">APPROVE ORDER</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">UPDATE DATA</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            
                                            <?php if(str_contains($app->model_type, 'PaymentLog')): ?>
                                                <div class="alert alert-success py-2 px-3 mb-0 small border-success">
                                                    <div class="d-flex justify-content-between">
                                                        <span>Nominal:</span>
                                                        <strong class="text-success">Rp
                                                            <?php echo e(number_format($app->new_data['amount'] ?? 0, 0, ',', '.')); ?></strong>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <span>Metode:</span>
                                                        <strong><?php echo e($app->new_data['payment_method'] ?? '-'); ?></strong>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <span>Tgl Bayar:</span>
                                                        <strong><?php echo e($app->new_data['payment_date'] ?? '-'); ?></strong>
                                                    </div>
                                                    <?php if(!empty($app->new_data['proof_file'])): ?>
                                                        <div class="mt-1 pt-1 border-top border-success">
                                                            <a href="<?php echo e(asset('storage/payment_proofs/' . $app->new_data['proof_file'])); ?>"
                                                                target="_blank" class="text-decoration-none fw-bold small">
                                                                <i class="bi bi-paperclip"></i> Lihat Bukti
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>

                                                
                                            <?php elseif(str_contains($app->model_type, 'Order')): ?>
                                                <div class="alert alert-primary py-2 px-3 mb-0 small border-primary">
                                                    <div class="d-flex justify-content-between">
                                                        <span>Invoice:</span>
                                                        <strong
                                                            class="text-primary"><?php echo e($app->new_data['invoice_number'] ?? '-'); ?></strong>
                                                    </div>
                                                    <div class="d-flex justify-content-between">
                                                        <span>Total:</span>
                                                        <strong>Rp
                                                            <?php echo e(number_format($app->new_data['total_price'] ?? 0, 0, ',', '.')); ?></strong>
                                                    </div>
                                                    <div class="mt-1 text-end">
                                                        <a href="<?php echo e(route('orders.show', $app->model_id)); ?>"
                                                            target="_blank" class="text-decoration-none small">
                                                            Lihat Detail Order <i class="bi bi-arrow-right"></i>
                                                        </a>
                                                    </div>
                                                </div>

                                                
                                            <?php elseif($app->new_data): ?>
                                                <ul class="list-unstyled mb-0 small border rounded p-2 bg-light">
                                                    <?php $__currentLoopData = $app->new_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                        <?php if(in_array($key, ['updated_at', 'created_at', 'id', 'user_id', 'sales_id'])): ?>
                                                            <?php continue; ?>
                                                        <?php endif; ?>

                                                        
                                                        <?php if(isset($app->original_data[$key]) && $app->original_data[$key] != $val): ?>
                                                            <li class="mb-1 border-bottom pb-1 last:border-0">
                                                                <strong class="text-uppercase text-muted"
                                                                    style="font-size: 0.7rem;">
                                                                    <?php echo e(str_replace('_', ' ', $key)); ?>

                                                                </strong>
                                                                <div class="d-flex align-items-center mt-1">
                                                                    <span
                                                                        class="text-danger text-decoration-line-through me-2 text-truncate"
                                                                        style="max-width: 100px;">
                                                                        <?php echo e($app->original_data[$key]); ?>

                                                                    </span>
                                                                    <i class="bi bi-arrow-right-short text-muted mx-1"></i>
                                                                    <span class="text-success fw-bold text-truncate"
                                                                        style="max-width: 120px;">
                                                                        <?php echo e($val); ?>

                                                                    </span>
                                                                </div>
                                                            </li>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td>
                                            <div class="d-flex gap-2 justify-content-end">

                                                
                                                <form action="<?php echo e(route('approvals.process', $app->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="action" value="approve_order">
                                                    

                                                    
                                                    <button type="submit"
                                                        class="btn btn-success btn-sm text-white shadow-sm"
                                                        onclick="confirmSubmit(event, 'Setujui Pengajuan?', 'Apakah Anda yakin ingin menyetujui transaksi ini? Stok akan berkurang otomatis.')">
                                                        <i class="bi bi-check-lg me-1"></i> Setuju
                                                    </button>
                                                </form>

                                                
                                                <form action="<?php echo e(route('approvals.process', $app->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="action" value="reject">

                                                    
                                                    <button type="submit"
                                                        class="btn btn-danger btn-sm text-white shadow-sm"
                                                        onclick="confirmSubmit(event, 'Tolak Pengajuan?', 'Yakin ingin menolak? Data order akan dibatalkan.')">
                                                        <i class="bi bi-x-lg me-1"></i> Tolak
                                                    </button>
                                                </form>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer bg-white py-3">
                <small class="text-muted"><i class="bi bi-info-circle me-1"></i> Data yang disetujui akan langsung
                    diterapkan ke sistem.</small>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sfa-bintang-native\resources\views/approvals/transaksi.blade.php ENDPATH**/ ?>