<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Order;
use App\Notifications\InvoiceDueReminder; // Jangan lupa import ini
use Carbon\Carbon;

class SendInvoiceReminders extends Command
{
    // 1. Nama perintah buat si Robot
    protected $signature = 'invoice:remind';

    // 2. Deskripsi tugasnya
    protected $description = 'Kirim notifikasi otomatis untuk tagihan H-3 jatuh tempo';

    // 3. Otak Robotnya (Logika Kerja)
    public function handle()
    {
        $this->info('Sedang memeriksa tagihan jatuh tempo...');

        // Cari order unpaid yang due_date-nya TEPAT 3 hari lagi dari sekarang
        $orders = Order::where('payment_status', 'unpaid')
                       ->whereDate('due_date', Carbon::now()->addDays(3))
                       ->get();

        $count = 0;
        foreach ($orders as $order) {
            // Kirim Notif ke Sales
            $order->user->notify(new InvoiceDueReminder($order));
            $count++;
            $this->info("Notif dikirim untuk Invoice: " . $order->invoice_number);
        }

        $this->info("Selesai! Total $count notifikasi terkirim.");
    }
}
