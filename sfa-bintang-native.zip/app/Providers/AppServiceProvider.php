<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator; // <--- 1. Tambahkan baris ini
use Illuminate\Support\Facades\View; // <--- Tambahkan ini
use Illuminate\Support\Facades\Auth; // <--- Tambahkan ini
use App\Models\Order;
use App\Models\PaymentLog;
use App\Models\Customer;
use App\Models\Approval; // Jika Anda punya model Approval terpusat

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot()
    {
        View::composer('*', function ($view) {
            $notifTotal = 0;
            $notifOrders = 0;
            $notifPayments = 0;

            if (Auth::check()) {
                $user = Auth::user();

                // Cek Role Manager
                if (in_array($user->role, ['manager_bisnis', 'manager_operasional', 'admin'])) {

                    // 1. HITUNG TOTAL (SAPU JAGAT)
                    // Ini pasti akurat karena menghitung semua baris 'pending' di tabel approvals
                    $notifTotal = Approval::where('status', 'pending')->count();

                    // 2. HITUNG RINCIAN (Opsional, buat submenu)
                    // Kita coba pakai 'like' biar bisa nangkep 'App\Models\Order' ataupun 'Order'
                    $notifOrders = Approval::where('status', 'pending')
                        ->where('model_type', 'LIKE', '%Order%')
                        ->count();

                    $notifPayments = Approval::where('status', 'pending')
                        ->where('model_type', 'LIKE', '%PaymentLog%')
                        ->count();
                }
            }

            // Kirim ke View (Sidebar)
            $view->with('notifTotal', $notifTotal);
            $view->with('notifPendingOrders', $notifOrders);
            $view->with('notifPendingPayments', $notifPayments);
        });
    }
}
