<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use App\Models\Order; // Import Model Order

class InvoiceDueReminder extends Notification
{
    use Queueable;

    public $order;

    // Terima data order saat notifikasi dibuat
    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    // Kirim via Database (Bisa juga via mail kalau mau email)
    public function via($notifiable)
    {
        return ['database'];
    }

    // Isi pesan yang disimpan ke database
    public function toArray($notifiable)
    {
        return [
            'order_id' => $this->order->id,
            'title' => 'Tagihan Jatuh Tempo!',
            'message' => 'Invoice ' . $this->order->invoice_number . ' (' . $this->order->customer->name . ') jatuh tempo 3 hari lagi.',
            'link' => route('orders.show', $this->order->id), // Link ke detail order
            'icon' => 'bi-exclamation-circle text-warning',
        ];
    }
}
