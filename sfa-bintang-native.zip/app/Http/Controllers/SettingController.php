<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Setting;

class SettingController extends Controller
{
    // TAMPILKAN HALAMAN SETTING
    public function index()
    {
        $categories = Category::all();

        // Ambil settingan jadi array biar gampang dipanggil (key => value)
        $settings = Setting::pluck('value', 'key')->toArray();

        return view('settings.index', compact('categories', 'settings'));
    }

    // SIMPAN SETTING UMUM
    public function updateGeneral(Request $request)
    {
        $data = $request->except('_token');

        foreach ($data as $key => $value) {
            Setting::updateOrCreate(['key' => $key], ['value' => $value]);
        }

        return back()->with('success', 'Pengaturan situs berhasil diperbarui!');
    }

    // TAMBAH KATEGORI
    public function storeCategory(Request $request)
    {
        $request->validate(['name' => 'required|unique:categories,name']);
        Category::create(['name' => $request->name]);
        return back()->with('success', 'Kategori baru berhasil ditambahkan!');
    }

    // HAPUS KATEGORI
    public function destroyCategory($id)
    {
        Category::destroy($id);
        return back()->with('success', 'Kategori berhasil dihapus.');
    }
}
