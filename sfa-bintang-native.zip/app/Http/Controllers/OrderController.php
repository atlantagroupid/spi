<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Customer;
use App\Models\OrderItem;
use App\Models\Approval;
use App\Models\User;
use App\Models\Receivable; // Tambahkan Model Receivable
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;

class OrderController extends Controller
{
    // 1. TAMPILKAN FORM ORDER
    public function create()
    {
        $user = Auth::user();

        // Mulai Query Customer
        $query = \App\Models\Customer::orderBy('name');

        // >>> FILTER KHUSUS SALES <<<
        // Jika yang login adalah Sales, tampilkan HANYA customer miliknya
        if ($user->role === 'sales') {
            $query->where('user_id', $user->id);
            // Atau jika sistem Anda berbasis Area:
            // $query->where('area', $user->area);
        }

        $customers = $query->get();

        // Hanya ambil produk yang stoknya ada
        $products = \App\Models\Product::where('stock', '>', 0)->orderBy('name')->get();

        return view('orders.create', compact('customers', 'products'));
    }

    // 2. PROSES SIMPAN ORDER
    public function store(Request $request)
    {
        // 1. Cek Customer & Aturan Bukti Bayar
        $customer = \App\Models\Customer::find($request->customer_id);

        $isTop = ($customer && $customer->top_days > 0);
        $proofRule = $isTop ? 'required' : 'nullable';

        // 2. VALIDASI INPUT
        $request->validate([
            'customer_id'   => ['required', 'exists:customers,id'],
            'due_date'      => ['required', 'date'],
            'product_id'    => ['required', 'array'],
            'product_id.*'  => ['exists:products,id'],
            'quantity'      => ['required', 'array'],
            'quantity.*'    => ['integer', 'min:1'],
            'payment_proof' => [$proofRule, 'file', 'mimes:jpg,jpeg,png,pdf', 'max:2048'],
            'notes'         => ['nullable', 'string'],
        ], [
            'customer_id.required'   => 'Silakan pilih customer terlebih dahulu.',
            'product_id.required'    => 'Keranjang masih kosong! Silakan tambah produk.',
            'payment_proof.required' => 'Customer ini tipe Kredit (TOP). WAJIB upload foto PO/SPK!',
        ]);

        DB::beginTransaction();
        try {
            // 3. Upload File (Jika ada)
            $proofPath = null;
            if ($request->hasFile('payment_proof')) {
                $file = $request->file('payment_proof');
                $filename = 'struk-' . time() . '.' . $file->getClientOriginalExtension();
                $file->storeAs('payment_proofs', $filename, 'public');
                $proofPath = $filename;
            }

            // 4. Buat Header Order
            $order = \App\Models\Order::create([
                'user_id'        => Auth::id(),
                'customer_id'    => $request->customer_id,
                'invoice_number' => 'SO-' . date('Ymd') . '-' . rand(1000, 9999),
                'total_price'    => 0, // Nanti diupdate
                'status'         => 'pending_approval',
                'payment_status' => 'unpaid',
                'due_date'       => $request->due_date,
                'notes'          => $request->notes,
                'payment_proof'  => $proofPath,
            ]);

            $calculatedTotal = 0;

            // 5. Simpan Item Belanja
            if ($request->has('product_id')) {
                $countItems = count($request->product_id);

                for ($i = 0; $i < $countItems; $i++) {
                    $prodId = $request->product_id[$i];
                    $qty    = $request->quantity[$i];

                    $product = \App\Models\Product::find($prodId);

                    if ($product) {
                        // Cek Stok
                        if ($product->stock < $qty) {
                            throw new \Exception("Stok {$product->name} tidak cukup (Sisa: {$product->stock})");
                        }

                        // Kurangi Stok
                        $product->decrement('stock', $qty);

                        // Cek Harga (Pakai Diskon jika ada)
                        $finalPrice = ($product->discount_price && $product->discount_price > 0)
                            ? $product->discount_price
                            : $product->price;

                        $subtotal = $finalPrice * $qty;
                        $calculatedTotal += $subtotal;

                        // Simpan Item
                        \App\Models\OrderItem::create([
                            'order_id'   => $order->id,
                            'product_id' => $product->id,
                            'quantity'   => $qty,
                            'price'      => $finalPrice,
                        ]);
                    }
                }
            }

            // 6. Update Total Akhir
            $order->update(['total_price' => $calculatedTotal]);

            // 7. BUAT TIKET APPROVAL
            \App\Models\Approval::create([
                'model_type' => \App\Models\Order::class,
                'model_id' => $order->id,
                'action' => 'approve_order',
                'original_data' => null,
                'new_data' => $order->toArray(),
                'status' => 'pending',
                'requester_id' => Auth::id(),
            ]);

            // CATATAN PENTING:
            // Tidak ada pembuatan Receivable (Piutang) di sini.
            // Piutang dipindah ke method approve().

            DB::commit();

            return redirect()->route('orders.show', $order->id)
                ->with('success', 'Order berhasil dibuat! Menunggu Approval Manager.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal membuat order: ' . $e->getMessage())->withInput();
        }
    }

    // 3. RIWAYAT ORDER
    public function index(Request $request)
    {
        $salesList = User::where('role', 'sales')->orderBy('name')->get();
        $query = Order::with(['user', 'customer'])->latest();

        // --- FILTERS ---
        if ($request->filled('store_name')) {
            $query->whereHas('customer', function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->store_name . '%');
            });
        }

        if (Auth::user()->role === 'sales') {
            $query->where('user_id', Auth::id());
        } elseif ($request->filled('sales_id')) {
            $query->where('user_id', $request->sales_id);
        }

        if ($request->filled('start_date') && $request->filled('end_date')) {
            $query->whereBetween('created_at', [
                $request->start_date . ' 00:00:00',
                $request->end_date . ' 23:59:59'
            ]);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->payment_status);
        }

        $orders = $query->paginate(10)->withQueryString();

        return view('orders.index', compact('orders', 'salesList'));
    }

    // 4. DETAIL ORDER
    public function show(Order $order)
    {
        $order->load(['customer', 'items.product', 'paymentLogs']);
        return view('orders.show', compact('order'));
    }

    // 5. MANAGER: APPROVE (DISINI KITA BUAT PIUTANG)
    // 5. MANAGER: APPROVE
    public function approve(Order $order)
    {
        if (!in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis'])) {
            abort(403);
        }

        if ($order->status !== 'pending_approval') {
            return back()->with('error', 'Order ini sudah diproses atau dibatalkan.');
        }

        // Cukup update status.
        // Piutang otomatis terhitung karena status order sudah 'approved'
        // dan payment_status masih 'unpaid' (default dari create).
        $order->update(['status' => 'approved']);

        return back()->with('success', 'Order berhasil disetujui! Transaksi ini sekarang tercatat sebagai piutang (jika belum lunas).');
    }

    // 6. MANAGER: REJECT (STOK KEMBALI, PIUTANG TIDAK DIBUAT)
    public function reject(Order $order)
    {
        if (!in_array(Auth::user()->role, ['manager_operasional', 'manager_bisnis'])) {
            abort(403);
        }

        $order->update(['status' => 'rejected']);

        // Kembalikan Stok
        foreach ($order->items as $item) {
            $item->product->increment('stock', $item->quantity);
        }

        return back()->with('success', 'Order ditolak dan stok dikembalikan.');
    }

    // 7. KASIR: PROSES & UPLOAD SURAT JALAN
    public function processOrder(Request $request, Order $order)
    {
        if (Auth::user()->role !== 'kasir') {
            abort(403);
        }

        $request->validate(['delivery_proof' => 'required|image|max:2048']);

        if ($order->status !== 'approved') {
            return back()->with('error', 'Order belum disetujui Manager.');
        }

        if ($request->hasFile('delivery_proof')) {
            $file = $request->file('delivery_proof');
            $filename = 'delivery-' . time() . '.' . $file->getClientOriginalExtension();
            $file->storeAs('delivery_proofs', $filename, 'public');

            // LOGIKA BARU: Tentukan Status Akhir
            // Defaultnya 'processed' (Sedang jalan/dikirim)
            $newStatus = 'processed';

            // TAPI, jika tipe pembayarannya CASH (atau Transfer Lunas di awal)
            // Maka transaksi dianggap SELESAI COMPLETED saat itu juga.
            // Asumsi: payment_type 'cash' artinya uang sudah di tangan.
            if ($order->payment_type == 'cash' || $order->payment_type == 'transfer') {
                $newStatus = 'completed';

                // Pastikan payment_status juga 'paid' jika belum
                $order->payment_status = 'paid';
            }

            $order->update([
                'status' => 'shipped', // Status baru: Sedang Dikirim
                'delivery_proof' => $filename
            ]);
        }

        // Ubah pesan notifikasi agar dinamis
        $msg = ($order->status == 'completed')
            ? 'Order Selesai! Barang dikirim & Pembayaran Lunas.'
            : 'Order diproses (Pengiriman). Menunggu pelunasan (Piutang).';

        return back()->with('success', $msg);
    }

    // 8. EXPORT EXCEL
    public function export(Request $request)
    {
        $query = Order::with(['user', 'customer'])->latest();

        if (Auth::user()->role === 'sales') {
            $query->where('user_id', Auth::id());
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $orders = $query->get();
        $fileName = 'Laporan-SO-' . date('d-m-Y_H-i') . '.xls';

        return response()->view('exports.orders', compact('orders'))
            ->header('Content-Type', 'application/vnd.ms-excel')
            ->header('Content-Disposition', 'attachment; filename="' . $fileName . '"')
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }

    // 9. PRINT PDF
    public function printPdf(Request $request)
    {
        $query = Order::with(['user', 'customer'])->latest();

        if (Auth::user()->role === 'sales') {
            $query->where('user_id', Auth::id());
        }

        $orders = $query->get();
        $pdf = Pdf::loadView('pdf.orders', compact('orders'));
        $pdf->setPaper('a4', 'landscape');

        return $pdf->stream('Laporan-Order.pdf');
    }

    public function edit($id)
    {
        $order = Order::with('items')->findOrFail($id);
        $user = Auth::user();

        // Mulai Query Customer
        $query = \App\Models\Customer::orderBy('name');

        // >>> FILTER KHUSUS SALES <<<
        // Jika yang login adalah Sales, tampilkan HANYA customer miliknya
        if ($user->role === 'sales') {
            $query->where('user_id', $user->id);
            // Atau jika sistem Anda berbasis Area:
            // $query->where('area', $user->area);
        }

        $customers = $query->get();

        // Hanya ambil produk yang stoknya ada
        $products = \App\Models\Product::where('stock', '>', 0)->orderBy('name')->get();
        // 1. Pastikan order milik sales tersebut
        if ($user->role == 'sales' && $order->user_id != $user->id) {
            abort(403, 'Akses Ditolak');
        }

        // 2. Pastikan Status masih boleh diedit
        if (!in_array($order->status, ['pending_approval', 'rejected'])) {
            return back()->with('error', 'Order ini sudah diproses dan tidak bisa diedit lagi.');
        }

        $products = \App\Models\Product::where('stock', '>', 0)->get();

        return view('orders.edit', compact('order', 'customers', 'products'));
    }

    public function update(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $request->validate([
            'customer_id' => 'required',
            'products' => 'required|array',
            'quantities' => 'required|array',
        ]);

        DB::transaction(function () use ($request, $order) {
            $totalPrice = 0;

            // 1. HAPUS ITEM LAMA
            \App\Models\OrderItem::where('order_id', $order->id)->delete();

            // 2. INSERT ITEM BARU
            foreach ($request->products as $index => $productId) {
                $qty = $request->quantities[$index];

                if ($qty > 0) {
                    $product = \App\Models\Product::find($productId);
                    $subtotal = $product->price * $qty;
                    $totalPrice += $subtotal;

                    \App\Models\OrderItem::create([
                        'order_id' => $order->id,
                        'product_id' => $productId,
                        'quantity' => $qty,
                        'price' => $product->price,
                        'subtotal' => $subtotal
                    ]);
                }
            }

            // 3. UPDATE DATA ORDER UTAMA
            $order->update([
                'customer_id' => $request->customer_id,
                'total_price' => $totalPrice,
                'notes' => $request->notes,
                'status' => 'pending_approval'
            ]);
        });

        return redirect()->route('orders.index')->with('success', 'Order berhasil diperbarui dan diajukan ulang!');
    }

    public function confirmArrival(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $user = Auth::user();

        // 1. CEK STATUS: Harus 'shipped'
        if (!in_array($order->status, ['shipped', 'processed'])) {
            return back()->with('error', 'Aksi ditolak. Status order tidak valid.');
        }

        // 2. CEK HAK AKSES (SECURITY CHECK)
        // Hanya boleh:
        // a. Sales pemilik order tersebut
        // b. Manager Operasional / Bisnis

        $isOwner = ($user->role == 'sales' && $order->user_id == $user->id);
        $isManager = in_array($user->role, ['manager_operasional', 'manager_bisnis']);

        if (!$isOwner && !$isManager) {
            abort(403, 'Akses Ditolak. Anda tidak berhak mengonfirmasi order ini.');
        }

        // --- PROSES UPDATE ---
        $order->status = 'delivered';

        // Auto Complete jika Cash & Lunas
        if ($order->payment_status == 'paid') {
            $order->status = 'completed';
        }

        $order->save();

        // Log nama pengonfirmasi (Opsional, buat history)
        // $order->logs()->create(['action' => 'confirmed_by', 'user_id' => $user->id]);

        return back()->with('success', 'Barang terkonfirmasi sudah diterima Customer.');
    }
}
