<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class CustomerController extends Controller
{
    // 1. Tampilkan Daftar Toko
    public function index(Request $request)
    {
        // 1. Ambil List Sales & Kategori untuk Dropdown
        $salesList = User::where('role', 'sales')->orderBy('name')->get();

        // Ambil kategori unik dari database (agar dropdown otomatis terisi sesuai data yg ada)
        // Pastikan kolom 'category' ada di tabel customers ya!
        $categories = Customer::select('category')
            ->distinct()
            ->whereNotNull('category')
            ->pluck('category');

        // 2. Mulai Query
        $query = Customer::with(['user']);

        // 3. Filter Role & Sales (Kode Lama)
        if (Auth::user()->role === 'sales') {
            $query->where('user_id', Auth::id());
        } else {
            if ($request->has('sales_id') && $request->sales_id != '') {
                $query->where('user_id', $request->sales_id);
            }
        }

        // 4. FILTER KATEGORI
        if ($request->has('category') && $request->category != '') {
            $query->where('category', $request->category);
        }

        // 5. Pencarian (Yang tadi sudah diperbaiki)
        if ($request->has('search') && $request->search != '') {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'LIKE', "%{$search}%")
                    ->orWhere('contact_person', 'LIKE', "%{$search}%")
                    ->orWhere('phone', 'LIKE', "%{$search}%")
                    ->orWhere('address', 'LIKE', "%{$search}%");
            });
        }

        // 6. Ambil Data
        $customers = $query->latest()->paginate(10);
        $customers->appends($request->all()); // Agar filter tidak hilang saat ganti halaman

        return view('customers.index', compact('customers', 'salesList', 'categories'));
    }

    // 2. Form Tambah Toko (Bisa diakses Sales)
    public function create()
    {
        return view('customers.create');
    }

    // 3. Simpan Toko Baru
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'contact_person' => 'nullable|string',
            'phone' => 'required|string|max:20',
            'address' => 'required|string',
            'category' => 'required|in:Workshop,Studio,Kontraktor,Customer',
            'top_days' => 'nullable|integer|min:0',
            'credit_limit' => 'nullable|numeric|min:0',
        ]);

        Customer::create([
            'user_id' => Auth::id(), // <--- OTOMATIS CATAT PEMILIK
            'name' => $request->name,
            'contact_person' => $request->contact_person,
            'phone' => $request->phone,
            'address' => $request->address,
            'category' => $request->category,
            'top_days' => $request->top_days ?? 0,
            'credit_limit' => $request->credit_limit ?? 0,
        ]);

        return redirect()->route('customers.index')->with('success', 'Toko berhasil didaftarkan!');
    }

    // 4. Form Edit (Admin Only)
    public function edit(Customer $customer)
    {
        return view('customers.edit', compact('customer'));
    }

    // 5. Update Data
    public function update(Request $request, Customer $customer)
    {
        // Validasi (sesuaikan dengan rule kamu)
        $request->validate([
            'name' => 'required',
            'phone' => 'required',
            'address' => 'required',
            'category' => 'required|in:Workshop,Studio,Kontraktor,Customer',
            'top_days' => 'nullable|integer|min:0',
            'credit_limit' => 'nullable|numeric|min:0',
        ]);

        // Ambil data yang boleh diedit
        $newData = $request->only(['name', 'email', 'phone', 'address', 'category', 'credit_limit', 'top_days']);

        // --- LOGIKA APPROVAL SALES ---
        // Jika yang edit BUKAN Manager, harus lewat persetujuan
        if (!in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])) {

            // Tentukan Action: Apakah ini update biasa atau Minta Naik Limit?
            $action = 'update';

            // Cek ada beda gak?
            $diff = array_diff_assoc($newData, $customer->only(array_keys($newData)));
            if (empty($diff)) return back()->with('info', 'Tidak ada perubahan data.');

            // Buat Tiket Approval
            \App\Models\Approval::create([
                'model_type' => \App\Models\Customer::class,
                'model_id' => $customer->id,
                'action' => 'update',
                'original_data' => $customer->toArray(),
                'new_data' => $newData,
                'status' => 'pending',
                'requester_id' => Auth::id(),
            ]);

            return redirect()->route('customers.index')
                ->with('success', 'Permintaan perubahan data Customer dikirim ke Manager.');
        }

        // Kalo Manager yang edit, langsung gass
        $customer->update($newData);
        return redirect()->route('customers.index')->with('success', 'Data Customer berhasil diperbarui.');
    }

    // 6. Hapus Data
    public function destroy(Customer $customer)
    {
        $customer->delete();
        return redirect()->route('customers.index')->with('success', 'Toko berhasil dihapus.');
    }
}
