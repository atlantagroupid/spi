<?php

namespace App\Http\Controllers;

use App\Models\Approval;
use App\Models\User;
use App\Models\Order;
use App\Models\PaymentLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ApprovalController extends Controller
{
    public function index()
    {
        // 1. Cek Hak Akses
        if (!in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional', 'kepala_gudang'])) {
            abort(403, 'Akses Ditolak');
        }

        $user = Auth::user();

        // 2. QUERY DASAR (Hanya yang Pending)
        $query = Approval::with('requester')->where('status', 'pending');

        // 3. FILTER "SAPU BERSIH" (Exclude Order & Payment)
        // Kita hanya mau menampilkan data Master (Customer & Product)
        // Jadi kita filter yang model_type-nya BUKAN Order dan BUKAN PaymentLog

        $query->where('model_type', 'NOT LIKE', '%Order%')
              ->where('model_type', 'NOT LIKE', '%PaymentLog%');


        // 4. FILTER SPESIFIK ROLE (Opsional, untuk pengetatan)
        if ($user->role === 'kepala_gudang') {
            // Kepala Gudang: Mutlak hanya Produk
            $query->where('model_type', 'like', '%Product%');
        }
        elseif ($user->role === 'manager_bisnis') {
            // Manager Bisnis: Di halaman ini hanya melihat Customer (karena order/piutang ada di menu lain)
            $query->where('model_type', 'like', '%Customer%');
        }
        // Manager Operasional: Melihat sisa-sisanya (Product & Customer)

        $approvals = $query->latest()->get();

        return view('approvals.index', compact('approvals'));
    }

    public function process(Request $request, $id)
    {
        $approval = Approval::findOrFail($id);
        $action = $request->input('action'); // 'approve' atau 'reject'

        // ===========================
        // A. LOGIKA REJECT (TOLAK)
        // ===========================
        if ($action === 'reject') {
            DB::transaction(function () use ($approval) {
                $approval->update([
                    'status' => 'rejected',
                    'approver_id' => Auth::id(),
                ]);

                // Sinkronisasi status ke data asli jika ditolak
                if ($approval->action === 'approve_order') {
                    // Update Order jadi Rejected & Balikin Stok
                    $order = Order::find($approval->model_id);
                    if ($order) {
                        $order->update(['status' => 'rejected']);
                        foreach ($order->items as $item) {
                            $item->product->increment('stock', $item->quantity);
                        }
                    }
                } elseif ($approval->action === 'approve_payment') {
                    PaymentLog::where('id', $approval->model_id)->update(['status' => 'rejected']);
                }
            });
            return back()->with('success', 'Pengajuan berhasil ditolak.');
        }

        // ===========================
        // B. LOGIKA APPROVE (SETUJU)
        // ===========================
        DB::beginTransaction();
        try {
            $modelClass = $approval->model_type;

            // 1. Update Data Master (Customer/Produk)
            if ($approval->action === 'update' || $approval->action === 'credit_limit_update') {
                $data = $modelClass::find($approval->model_id);
                if ($data) $data->update($approval->new_data);
            } elseif ($approval->action === 'create') {
                $modelClass::create($approval->new_data);
            }

            // 2. Approve Order (Transaksi)
            elseif ($approval->action === 'approve_order') {
                $order = Order::find($approval->model_id);
                if ($order) $order->update(['status' => 'approved']);
            }

            // 3. Approve Pembayaran (Receivable)
            elseif ($approval->action === 'approve_payment') {
                $log = PaymentLog::find($approval->model_id);
                if ($log) {
                    $log->update(['status' => 'approved']);

                    // Hitung ulang status lunas/parsial
                    $order = Order::find($log->order_id);
                    if ($order) {
                        $totalPaid = $order->paymentLogs()->where('status', 'approved')->sum('amount');
                        if ($totalPaid >= $order->total_price) {
                            $order->update(['payment_status' => 'paid']);
                        } else {
                            $order->update(['payment_status' => 'partial']);
                        }
                    }
                }
            }

            // Tandai Approval Selesai
            $approval->update([
                'status' => 'approved',
                'approver_id' => Auth::id()
            ]);

            DB::commit();
            return back()->with('success', 'Pengajuan disetujui!');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    // 1. Halaman Transaksi (Order Baru)
    public function transaksi()
    {
        // Ambil data yang model_type-nya mengandung kata 'Order'
        // Sesuaikan namespace model-nya jika perlu, misal 'App\Models\Order'
        $approvals = Approval::where('model_type', 'like', '%Order%')
            ->where('status', 'pending') // <--- INI KUNCINYA
            ->orderBy('created_at', 'desc')
            ->get();

        // Kirim ke view khusus transaksi
        return view('approvals.transaksi', compact('approvals'));
    }

    // 2. Halaman Bayar Piutang (PaymentLog)
    public function piutang()
    {
        // Ambil data yang model_type-nya mengandung kata 'PaymentLog'
        $approvals = Approval::where('model_type', 'like', '%PaymentLog%')
            ->where('status', 'pending') // <--- INI KUNCINYA
            ->orderBy('created_at', 'desc')
            ->get();

        // Kirim ke view khusus piutang
        return view('approvals.piutang', compact('approvals'));
    }

    // Opsional: Jika nanti mau buat halaman khusus Customer Approval
    public function customer()
    {
        $approvals = Approval::where('model_type', 'like', '%Customer%')->get();
        return view('approvals.customer', compact('approvals'));
    }
}
