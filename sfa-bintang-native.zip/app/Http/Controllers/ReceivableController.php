<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Notifications\InvoiceDueReminder;
use App\Exports\ReceivableExport;
use Maatwebsite\Excel\Facades\Excel;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

// --- IMPORT MODELS ---
use App\Models\Approval;
use App\Models\PaymentLog;
use App\Models\Order;

class ReceivableController extends Controller
{
    // 1. LIST UNPAID INVOICES
    // 1. LIST UNPAID INVOICES
    public function index()
    {
        $invoices = Order::with(['customer', 'user', 'paymentLogs'])
            ->whereIn('payment_status', ['unpaid', 'partial'])
            // >>> TAMBAHAN PENTING <<<
            // Pastikan hanya order yang SUDAH DIAKUI (Approved/Processed/Completed) yang muncul.
            // Order 'Pending Approval' atau 'Rejected' JANGAN dianggap hutang.
            ->whereIn('status', ['approved', 'processed', 'completed'])
            // >>> SELESAI TAMBAHAN <<<
            ->orderBy('due_date', 'asc')
            ->paginate(10);

        return view('receivables.index', compact('invoices'));
    }

    // 2. SEND REMINDERS (H-3 Due Date)
    public function sendReminders()
    {
        $orders = Order::where('payment_status', 'unpaid')
            ->whereDate('due_date', Carbon::now()->addDays(3)->format('Y-m-d'))
            ->get();

        $count = 0;
        foreach ($orders as $order) {
            if ($order->user) {
                $order->user->notify(new InvoiceDueReminder($order, 3));
                $count++;
            }
        }

        return back()->with('success', "Berhasil! $count notifikasi dikirim ke sales.");
    }

    // 3. EXPORT EXCEL
    public function export()
    {
        $fileName = 'laporan_piutang_' . date('d-m-Y') . '.xlsx';
        return Excel::download(new ReceivableExport, $fileName);
    }

    // 4. COMPLETED (PAID) INVOICES
    public function completed()
    {
        $invoices = Order::with(['customer', 'user'])
            ->where('payment_status', 'paid')
            ->latest()
            ->paginate(10);

        return view('receivables.completed', compact('invoices'));
    }

    // 5. PRINT PDF
    public function printPdf(Request $request)
    {
        $query = Order::with(['user', 'customer'])
            ->whereIn('payment_status', ['unpaid', 'partial'])
            ->whereIn('status', ['approved', 'processed', 'completed']) // <--- Tambahkan ini
            ->latest();

        if ($request->filled('sales_id')) {
            $query->where('user_id', $request->sales_id);
        }

        $receivables = $query->get();

        $pdf = Pdf::loadView('pdf.receivables', compact('receivables'));
        $pdf->setPaper('a4', 'landscape');

        return $pdf->stream('Laporan-Piutang.pdf');
    }

    // 6. SHOW DETAIL (With Pending Amount Logic)
    public function show($id)
    {
        $order = Order::with(['customer', 'paymentLogs.user'])->findOrFail($id);

        // Paid (Approved)
        $paidAmount = $order->paymentLogs()->where('status', 'approved')->sum('amount');

        // Pending (Waiting Approval)
        $pendingAmount = $order->paymentLogs()->where('status', 'pending')->sum('amount');

        // Remaining Debt
        $remaining = $order->total_price - $paidAmount;

        return view('receivables.show', compact('order', 'paidAmount', 'pendingAmount', 'remaining'));
    }

    // 7. STORE PAYMENT (Input by Cashier/Sales)
    public function store(Request $request) // <--- UBAH DISINI: Hapus ", Order $order"
    {
        if (!in_array(Auth::user()->role, ['finance', 'sales'])) {
            abort(403, 'Hanya Finance yang boleh menginput pembayaran.');
        }

        $request->validate([
            'order_id'       => 'required|exists:orders,id', // <--- TAMBAH VALIDASI INI BIAR AMAN
            'amount'         => 'required|numeric|min:1',
            'payment_date'   => 'required|date',
            'payment_method' => 'required',
            'proof_file'     => 'nullable|image|max:2048'
        ]);

        // Handle File Upload
        $proofPath = null;
        if ($request->hasFile('proof_file')) {
            $filename = 'pay-' . time() . '.' . $request->file('proof_file')->getClientOriginalExtension();
            $request->file('proof_file')->storeAs('payment_proofs', $filename, 'public');
            $proofPath = $filename;
        }

        DB::beginTransaction();
        try {
            // A. Create Payment Log (Pending)
            $paymentLog = PaymentLog::create([
                'order_id'       => $request->order_id, // <--- UBAH DISINI: Ambil dari request form
                'user_id'        => Auth::id(),
                'amount'         => $request->amount,
                'payment_date'   => $request->payment_date,
                'payment_method' => $request->payment_method,
                'proof_file'     => $proofPath,
                'status'         => 'pending',
                'notes'          => $request->notes
            ]);

            // B. Create Approval Ticket
            Approval::create([
                'model_type'    => PaymentLog::class,
                'model_id'      => $paymentLog->id,
                'action'        => 'approve_payment',
                'original_data' => null,
                'new_data'      => $paymentLog->toArray(),
                'status'        => 'pending',
                'requester_id'  => Auth::id(),
            ]);

            DB::commit();
            return back()->with('success', 'Pembayaran berhasil diinput. Menunggu verifikasi Manager.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal menyimpan pembayaran: ' . $e->getMessage());
        }
    }

    // 8. APPROVE PAYMENT (Manual from Receivable Detail)
    public function approve($log_id)
    {
        // 1. Validasi Hak Akses Manager
        if (!in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])) {
            abort(403);
        }

        DB::transaction(function () use ($log_id) {
            $log = PaymentLog::findOrFail($log_id);

            // A. Update Log Status (Log Pembayaran jadi Approved)
            $log->update(['status' => 'approved']);

            // B. Update Order Payment Status (Cek Lunas atau Belum)
            $order = Order::findOrFail($log->order_id);

            // Hitung total yang SUDAH diapprove (termasuk yang baru saja diapprove ini)
            $totalPaid = $order->paymentLogs()->where('status', 'approved')->sum('amount');

            // Set Payment Status (Lunas atau Parsial)
            if ($totalPaid >= $order->total_price) {
                $order->payment_status = 'paid';
            } else {
                $order->payment_status = 'partial';
            }

            // >>> LOGIKA BARU: AUTO COMPLETE ORDER <<<
            // Syarat Order Selesai: (1) Uang LUNAS + (2) Barang SUDAH DIKIRIM/DIPROSES
            // GANTI LOGIKA AUTO COMPLETE
            // Syarat: Uang Lunas + Barang Sudah Diterima Customer
            if ($order->payment_status == 'paid' && $order->status == 'delivered') {
                $order->status = 'completed';
            }

            // Simpan perubahan ke database (Payment Status & Order Status)
            $order->save();

            // C. Sync Approval Ticket Status (Update tiket notifikasi jadi approved)
            Approval::where('model_type', PaymentLog::class)
                ->where('model_id', $log_id)
                ->where('status', 'pending')
                ->update(['status' => 'approved', 'approver_id' => Auth::id()]);
        });

        return back()->with('success', 'Pembayaran disetujui. Status transaksi diperbarui.');
    }

    // 9. REJECT PAYMENT (Manual from Receivable Detail)
    public function reject($log_id)
    {
        if (!in_array(Auth::user()->role, ['manager_bisnis', 'manager_operasional'])) {
            abort(403);
        }

        DB::transaction(function () use ($log_id) {
            $log = PaymentLog::findOrFail($log_id);
            $log->update(['status' => 'rejected']);

            // Sync Approval Ticket Status
            Approval::where('model_type', PaymentLog::class)
                ->where('model_id', $log_id)
                ->where('status', 'pending')
                ->update(['status' => 'rejected', 'approver_id' => Auth::id()]);
        });

        return back()->with('error', 'Pembayaran ditolak.');
    }
}
