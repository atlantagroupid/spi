<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schedule;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ReceivableController;
use App\Http\Controllers\VisitController;
use App\Http\Controllers\ApprovalController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SettingController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// --- SCHEDULER (Jadwal Otomatis) ---
Schedule::command('invoice:remind')->dailyAt('08:00');

// --- PUBLIC & GUEST ---
Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

// --- AUTHENTICATED USER (Harus Login) ---
Route::middleware('auth')->group(function () {

    // Route Khusus Pembayaran (Taruh di urutan atas)
    Route::post('/payment/process/{id}', [App\Http\Controllers\ReceivableController::class, 'store'])
        ->name('payment.process');

    // 1. Form Buat Rencana
    Route::get('/visits/create-plan', [VisitController::class, 'createPlan'])->name('visits.createPlan');

    // 2. Simpan Rencana (Untuk form action nanti)
    Route::post('/visits/store-plan', [VisitController::class, 'storePlan'])->name('visits.storePlan');

    // A. DASHBOARD & AUTH
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // B. PROFILE & NOTIFIKASI
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');

    Route::get('/notifications/read', function () {
        Auth::user()->unreadNotifications->markAsRead();
        return back();
    })->name('notifications.markRead');

    // C. MANAJEMEN USER (Hanya Manager Operasional)
    Route::middleware(['role:manager_operasional'])->group(function () {
        Route::resource('users', UserController::class);

        // PENGATURAN SITUS
        Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
        Route::post('/settings/general', [SettingController::class, 'updateGeneral'])->name('settings.updateGeneral');
        Route::post('/settings/category', [SettingController::class, 'storeCategory'])->name('settings.storeCategory');
        Route::delete('/settings/category/{id}', [SettingController::class, 'destroyCategory'])->name('settings.destroyCategory');
    });

    // D. MASTER DATA

    // 1. DATA PRODUK (Gudang, Ops, Purchase) - Manager Bisnis DIBLOKIR
    Route::middleware(['role:manager_operasional,kepala_gudang,admin_gudang,purchase'])->group(function () {
        Route::resource('products', ProductController::class);

        // Custom Routes Produk
        Route::post('/products/{id}/update-restock', [ProductController::class, 'updateRestock'])->name('products.updateRestock');
        Route::post('/products/{id}/update-discount', [ProductController::class, 'updateDiscount'])->name('products.updateDiscount');
    });

    // 2. DATA CUSTOMER (Semua boleh KECUALI Gudang & Purchase - sesuaikan role di Controller/Middleware jika perlu)
    Route::resource('customers', CustomerController::class);

    // E. TRANSAKSI (ORDERS)

    // Custom Routes Order
    Route::get('/orders/print-pdf', [OrderController::class, 'printPdf'])->name('orders.printPdf');
    Route::get('/orders/export', [OrderController::class, 'export'])->name('orders.export');

    // Approval & Processing Order
    Route::post('/orders/{order}/approve', [OrderController::class, 'approve'])->name('orders.approve');
    Route::post('/orders/{order}/reject', [OrderController::class, 'reject'])->name('orders.reject');
    Route::post('/orders/{order}/process', [OrderController::class, 'processOrder'])->name('orders.process');

    // Konfirmasi Barang Diterima (Delivery Confirmation) oleh Customer
    Route::post('/orders/{id}/confirm-arrival', [App\Http\Controllers\OrderController::class, 'confirmArrival'])->name('orders.confirmArrival');
    // Resource Order
    Route::resource('orders', OrderController::class);

    // F. KUNJUNGAN (VISIT)
    // Perencanaan
    Route::get('/visits/plan', [VisitController::class, 'createPlan'])->name('visits.plan');
    Route::post('/visits/plan', [VisitController::class, 'storePlan'])->name('visits.storePlan');

    // Eksekusi (Check-in dari Rencana)
    // Route::get('/visits/{visit}/perform', [VisitController::class, 'perform'])->name('visits.perform');
    // Route::put('/visits/{visit}', [VisitController::class, 'update'])->name('visits.update');
    // Route untuk Check-in (Hanya mengubah status & waktu mulai)
    Route::post('/visits/{visit}/check-in', [App\Http\Controllers\VisitController::class, 'checkIn'])->name('visits.checkIn');

    // Route untuk Check-out (Halaman Upload Foto & GPS)
    Route::get('/visits/{visit}/perform', [App\Http\Controllers\VisitController::class, 'perform'])->name('visits.perform');
    Route::put('/visits/{visit}/update', [App\Http\Controllers\VisitController::class, 'update'])->name('visits.update');
    // Riwayat & Manual Check-in
    Route::get('/visits/create', [VisitController::class, 'create'])->name('visits.create');
    Route::post('/visits', [VisitController::class, 'store'])->name('visits.store');
    Route::get('/visits', [VisitController::class, 'index'])->name('visits.index');

    // Route Update Target Visit (Khusus Manager Bisnis)
    Route::middleware(['role:manager_bisnis'])->group(function () {
        Route::post('/visits/update-target', [VisitController::class, 'updateTarget'])->name('visits.updateTarget');
    });

    // G. KEUANGAN & PIUTANG (RECEIVABLES)
    // Custom Routes Receivable
    Route::get('/receivables/print-pdf', [ReceivableController::class, 'printPdf'])->name('receivables.printPdf');
    Route::get('/receivables/export', [ReceivableController::class, 'export'])->name('receivables.export');
    Route::get('/receivables/completed', [ReceivableController::class, 'completed'])->name('receivables.completed');
    Route::post('/receivables/remind', [ReceivableController::class, 'sendReminders'])->name('receivables.remind');

    // Approval Pembayaran
    Route::post('/payment-logs/{id}/approve', [ReceivableController::class, 'approve'])->name('payments.approve');
    Route::post('/payment-logs/{id}/reject', [ReceivableController::class, 'reject'])->name('payments.reject');

    // Resource Receivable (Only specific methods)
    // NOTE: 'index' route here replaces the manual Route::get('/receivables', ...) you had before
    Route::resource('receivables', ReceivableController::class)->only(['index', 'show', 'store']);

    // H. APPROVAL SYSTEM (PUSAT APPROVAL MANAGER)
    Route::get('/approvals', [ApprovalController::class, 'index'])->name('approvals.index');
    Route::post('/approvals/{id}/process', [ApprovalController::class, 'process'])->name('approvals.process');


    // RUTE KHUSUS PEMBAYARAN PIUTANG (Wajib ada!)
    Route::post('/receivables/{id}/pay', [ReceivableController::class, 'store'])->name('receivables.pay');

    // Opsional: Jika ada kode lama yang mencari 'orders.pay', kita arahkan ke sini juga biar gak error
    Route::post('/orders/{id}/pay-alias', [ReceivableController::class, 'store'])->name('orders.pay');

    Route::prefix('approvals')->name('approvals.')->group(function () {
        // Memanggil function transaksi()
        Route::get('/transaksi', [ApprovalController::class, 'transaksi'])->name('transaksi');

        // Memanggil function piutang()
        Route::get('/bayar-piutang', [ApprovalController::class, 'piutang'])->name('piutang');
    });

    Route::post('/users/update-target', [App\Http\Controllers\UserController::class, 'updateSalesTarget'])->name('users.updateTarget');

    // Route untuk update target (Kunjungan & Omset)
    Route::post('/visits/update-target', [App\Http\Controllers\VisitController::class, 'updateTarget'])->name('visits.updateTarget');
});
