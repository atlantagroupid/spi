<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        // Hapus user lama biar bersih (Opsional, hati-hati kalau data real)
        // User::truncate();

        $password = Hash::make('password'); // Password sama semua biar gampang tes

        $users = [
            // 1. LEVEL TERTINGGI
            [
                'name' => 'Bpk. Super Manager',
                'email' => 'manager_ops@bintang.com',
                'role' => 'manager_operasional', // Super Admin
                'sales_code' => null,
            ],
            [
                'name' => 'Ibu Manager Bisnis',
                'email' => 'manager_biz@bintang.com',
                'role' => 'manager_bisnis', // Atasan Sales/Finance
                'sales_code' => null,
            ],

            // 2. DIVISI GUDANG
            [
                'name' => 'Pak Kepala Gudang',
                'email' => 'kepala_gudang@bintang.com',
                'role' => 'kepala_gudang',
                'sales_code' => null,
            ],
            [
                'name' => 'Staf Admin Gudang',
                'email' => 'admin_gudang@bintang.com',
                'role' => 'admin_gudang',
                'sales_code' => null,
            ],

            // 3. DIVISI LAIN
            [
                'name' => 'Staf Purchase',
                'email' => 'purchase@bintang.com',
                'role' => 'purchase',
                'sales_code' => null,
            ],
            [
                'name' => 'Staf Finance',
                'email' => 'finance@bintang.com',
                'role' => 'finance',
                'sales_code' => null,
            ],
            [
                'name' => 'Mbak Kasir',
                'email' => 'kasir@bintang.com',
                'role' => 'kasir',
                'sales_code' => null,
            ],

            // 4. SALES (Butuh Kode Unik)
            [
                'name' => 'Andi Sales (Area Kota)',
                'email' => 'andi@bintang.com',
                'role' => 'sales',
                'sales_code' => 'SALES-001', // Kode Unik
            ],
            [
                'name' => 'Budi Sales (Area Barat)',
                'email' => 'budi@bintang.com',
                'role' => 'sales',
                'sales_code' => 'SALES-002',
            ],
        ];

        foreach ($users as $userData) {
            User::updateOrCreate(
                ['email' => $userData['email']], // Cek email biar gak duplikat
                array_merge($userData, ['password' => $password])
            );
        }
    }
}
