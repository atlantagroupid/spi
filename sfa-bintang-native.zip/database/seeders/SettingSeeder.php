<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
{
    // 1. Default Kategori
    $cats = ['Lantai', 'Dinding', 'Granit', 'Sanitary', 'Aksesoris'];
    foreach($cats as $c) {
        \App\Models\Category::firstOrCreate(['name' => $c]);
    }

    // 2. Default Pengaturan
    \App\Models\Setting::updateOrCreate(['key' => 'app_name'], ['value' => 'SFA Bintang Interior']);
    \App\Models\Setting::updateOrCreate(['key' => 'company_name'], ['value' => 'CV. Bintang Interior & Keramik']);
    \App\Models\Setting::updateOrCreate(['key' => 'company_address'], ['value' => 'Jl. Teuku Iskandar, Banda Aceh']);
    \App\Models\Setting::updateOrCreate(['key' => 'company_phone'], ['value' => '0812-3456-7890']);
}
}
